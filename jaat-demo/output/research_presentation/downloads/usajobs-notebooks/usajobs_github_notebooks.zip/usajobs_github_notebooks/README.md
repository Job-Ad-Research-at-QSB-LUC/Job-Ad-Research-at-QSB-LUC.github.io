# USAJOBS: coded postings to occupational relatedness

Three worked notebooks, using the previously analyzed full USAJOBS corpus:

1. **01_jaat_records_to_occupation_task_profiles.ipynb** — check saved JAAT codes, deduplicate task retrievals within postings, count occupation–task incidences, inspect support and prevalence, and export profiles.
2. **02_profiles_to_relatedness.ipynb** — calculate the corpus RCA reference, retain supported links, normalize square-root RCA, inspect RN–medical manager shared-task contributions, and rank related occupations.

3. **03_relatedness_to_figure2.ipynb** — reproduce the paper’s benchmark results as a control, evaluate USAJOBS with the same ranking and benchmark functions, and render a USAJOBS version of Figure 1.

## Run

Use Python 3.13 (the tested version), install `requirements.txt`, and open the notebooks with your preferred Jupyter client. Run cells in order from this directory. A Jupyter interface is not included in the requirements; the execution dependencies are.

Run `pip install -r requirements.txt` in your notebook environment. The configuration cell downloads pinned public [coded postings](https://huggingface.co/datasets/loyoladatamining/usajobs_coded) and [date metadata](https://huggingface.co/datasets/loyoladatamining/usajobs_html_metadata) if the input folders are absent (about 0.85 GB). No Hugging Face account or token is needed. Extract the complete notebook package first; it includes `download_public_inputs.py` and reference data. You can instead set `INPUT` and `META` to existing monthly folders. Notebook 2 includes aggregate inputs and runs independently.

The coded dataset is pinned to `2ac18625eec954234e1b838907ef05f3961dd4bd`; metadata to `b3cd0a88da23b2f5a7b0aef6303abe3fc3704640`. Downloads are anonymous and verified against public file hashes. No raw-text download is required. The run manifest fingerprints both inputs. Public dates produce 17,348 end-before-start records versus 10,674 in the historical local input; this diagnostic difference does not change the profiles.

Notebook 2 runs independently from the compact aggregate counts in `data/`, or uses matching outputs from Notebook 1 when present. It needs no raw postings and no model download. All three notebooks have saved outputs for review on GitHub.

## Inputs and choices

- 3,089,366 distinct posting IDs; start dates January 2017–March 2026. Coverage refers to the assembled corpus, not all federal hiring.
- One supplied TitleMatch assignment per posting. TaskMatch outputs are semicolon-delimited task IDs. No additional title-score filter.
- All supplied postings; weight 1. Notebook 1 contains a commented explanation of inverse-probability weighting for a genuinely sampled alternative.
- Task counts are unique posting–task pairs. Taskless postings remain in posting-prevalence denominators. Distinct posting IDs are required.
- O*NET task dictionary 27.2; occupation-code eligibility 31.0, matching the existing USAJOBS analysis. Invalid IDs/codes are reported and excluded from profile construction. These two versions are intentional, not an assertion that all inputs use one release.
- At least five postings per retained occupation–task link. The default corpus reference uses retained incidences after support filtering, matching the paper. Notebook 2 offers the earlier pre-support reference as an explicitly labeled sensitivity. No RCA ≥ 1 cutoff. The supplied NLx occupation–task exclusion list is applied before recomputing RCA; unreviewed links remain. This transfers pair exclusions, not a new independent review of USAJOBS postings.
- RCA uses task-incidence shares, not posting prevalence; square-root transformation followed by unit L2 normalization.
- Detailed RN and manager occupations are 29-1141.00 and 11-9111.00. A separate calculation shows the prior pipeline's equal mean of specialty-pair similarities for the six-digit groups.
- At least 200 postings for destinations in the displayed ranking; this does not change the reference or fitted vectors.
- Exact extraction model revisions and raw-text inference were not independently reconstructed. These notebooks reproduce coded records → results, not raw text → historical codes.

O*NET source archives: https://www.onetcenter.org/db_releases.html . O*NET attribution/license information: https://www.onetcenter.org/license_db.html . `tasks.csv` is the project’s 27.2 task dictionary; `occupations.csv` is its 31.0 occupation list. File fingerprints are in `data/SHA256.json`.

## Verification and review

`verification.json` records execution of all three notebooks, agreement of the default model with the unchanged paper representation function, and agreement of the optional earlier reference setting with the prior USAJOBS analysis. Notebook 3 independently reconstructs and verifies the paper’s frozen rankings and all six summaries before calculating USAJOBS results. These checks do not validate extraction accuracy.

The code and explanatory text were prepared with Codex. Review priorities: historical extraction provenance; the full-corpus and reference-population choices; support filtering; and interpretation of the detailed versus six-digit example. The existing RCA specification was examined retrospectively, not selected in a preregistered held-out comparison.

This package is separate from the NLx paper replication and does not contain NLx data. No repository-wide license is asserted for contributed code; the repository owner should apply the intended code license before publishing. Source data remain governed by their source terms.

## Figure 1 replication and included inputs

`paper_code_and_inputs/` contains the actual paper ranking/evaluation functions, original renderer, published O*NET 31.0 related-occupation lists, fixed paper candidate mappings, aggregate observed transitions, expected paper results, public RN workbook and the released NLx similarity matrix. File hashes attest that this subset is copied unchanged. No underlying NLx records or task profiles are included. The original paper README in that subdirectory describes the broader release; commands for files outside this deliberately selected subset are not supplied here. Use Notebook 3 for the included workflow.

`usajobs_figure_rendering.py` adapts only presentation: USAJOBS heading/source callout, validation-axis scale, selected-pair arrow handling, and four-row stacked Panel H (posting tasks higher / equal recovery / O*NET higher). The original renderer remains available unchanged for the paper control. Benchmarks and scores are recalculated, not copied from the paper figure.

USAJOBS benchmark candidate groups intersect the paper’s eligible specialties with USAJOBS occupations having at least 200 postings and nonempty vectors. Partial group membership is explicit in `results/figure2_usajobs/candidate_memberships.csv`; all original outcome denominator mass is preserved. Both models use the identical revised groups. Population differences mean headline percentages cannot be interpreted as a like-for-like improvement over the NLx estimates.

The new figure includes all four headline benchmarks; the results table also includes 5- and 10-year NLSY97/PSID outcomes. The absence of a two-model USAJOBS review ledger is disclosed. Figure 1 is a replication of the analysis using another corpus, not an exact reproduction of the original numbers.

To trace benchmark source construction, consult `paper_code_and_inputs/source_provenance.json` and the included original paper README. The notebook begins with aggregate benchmark releases; it does not reconstruct raw survey extraction or resume histories. Source provenance paths may refer to the broader paper release.

## Saved USAJOBS Figure 1 results

The executed figure has mean capture/recovery of 12.35% versus 11.38% for SST, 19.08% versus 18.85% for EMSI, 15.25% versus 17.48% for CPS–SIPP, and 9.83% versus 10.63% for three-year NLSY97–PSID (USAJOBS task model versus O*NET). The results are mixed; this demonstration does not reproduce the paper’s across-benchmark advantage. Respective evaluated-origin counts are 428, 261, 85 and 58. The five- and ten-year outcomes and coverage are in the saved tables.

`preview/` contains the generated figure PDF/PNG and results tables. Re-running Notebook 3 writes fresh results under `results/figure2_usajobs/`. No dashboard or existing paper release is changed.

## Production alignment (15 October 2026)
Notebook 2 applies `data/occupation_task_exclusions.csv`, the same rejected/incomplete detailed occupation-task pairs removed in the NLx production model. Unreviewed pairs remain. RCA is recalculated after exclusion and minimum support. These are transferred pair-level decisions, not new USAJOBS LLM judgments. Notebook 3 independently checks the vectors using the paper function and reports all six benchmarks; G–H show SST and EMSI with a unique SOC6 total. Federal coverage, corpus dates, unit weights and unique-posting units remain distinct from NLx.

## Figure representation comparisons (15 October 2026)

Notebook 3 now calculates the task, task-to-DWA, and random-group rows from USAJOBS inputs using `aggregation_comparison.py` and `data/production_task_dwa_bridge.csv`. It evaluates all 99 frequency-constrained random groupings; the figure shows their mean, not a selected draw. It saves all six benchmark results, per-origin averages, draw-level means and coverage under `results/figure2_usajobs/aggregation_*`. The figure colors all posting-derived representations blue and published O*NET lists red. Panel H still compares original posting tasks with published O*NET lists.

The bridge is a deduplicated public task/DWA export of the production crosswalk, not an assertion that it is the exact official 27.2 release. The separate native-activity SI test uses official 27.2 for both sources. Active USAJOBS DWA count: 2,042; NLx: 2,050. Category inventories and active features are different quantities. No benchmark outcomes determine the random assignments. Code and prose changes were prepared with Codex.

## Figure update (16 October 2026)
Panel F uses pre-filter task incidence allocated equally across official O*NET 27.2 DWAs and checks the native activity inventory at each SOC prefix. Figure 1 and USAJOBS Figure 2 use identical layout and definitions with separate data. Panel G includes tasks and actual DWAs, not randomized groups. The official source is https://www.onetcenter.org/dl_files/database/db_27_2_text/Tasks%20to%20DWAs.txt (O*NET database, CC BY 4.0); the included CSV preserves the native occupation assignments. Figure percentages are rounded to whole numbers; CSVs retain precision.
