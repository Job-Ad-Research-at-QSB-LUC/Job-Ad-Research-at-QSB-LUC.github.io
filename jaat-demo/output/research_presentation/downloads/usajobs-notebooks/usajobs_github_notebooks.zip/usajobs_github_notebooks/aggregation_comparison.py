"""Task aggregation diagnostic; no model selection or outcome-fitted parameters.
Use the production task-to-DWA bridge also used in the NLx diagnostic.
Shuffle whole bridge rows within degree and task-frequency decile, preserving
coverage, category sizes, per-task degree and mapped mass for each occupation.
"""
import numpy as np
import pandas as pd
from scipy import sparse

def compare(M, codes, task_ids, group_sets, observed, by, metrics, bridge_path, out, repeats=0):
    ref=by[by['mode'].eq('equal_length') & by.included].copy()
    oi={c:i for i,c in enumerate(codes)};prep={}
    for ds,g in ref.groupby('dataset',sort=False):
        groups=group_sets[ds];names=sorted(groups);ci={c:i for i,c in enumerate(names)}
        rr=[];cc=[];vv=[]
        for i,c in enumerate(names):
            for code in groups[c]:rr.append(i);cc.append(oi[code]);vv.append(1/len(groups[c]))
        G=sparse.csr_matrix((vv,(rr,cc)),shape=(len(names),len(codes)))
        origins=g.origin.tolist();ix={c:i for i,c in enumerate(origins)}
        T=np.zeros((len(origins),len(names)));den=g.set_index('origin').denominator
        for r in observed[observed.dataset.eq(ds)].itertuples():
            if r.origin in ix and r.destination in ci:T[ix[r.origin],ci[r.destination]]=r.mass/den[r.origin]
        prep[ds]=(G,np.array([ci[c] for c in origins]),T,g)
    def vectors(Y):
        mass=np.asarray(Y.sum(0)).ravel();p=mass/mass.sum()
        return metrics.representation(Y,np.divide(1,p,out=np.zeros_like(p),where=p>0))[1]
    results=[];details=[];random_sum={ds:np.zeros(len(p[3])) for ds,p in prep.items()}
    def evaluate(Y,model,draw=-1):
        V=vectors(Y);S=metrics.cosine_matrix(V)
        for ds,(G,ids,T,g) in prep.items():
            B=np.asarray((G@S)@G.T)[ids,:];B[np.arange(len(ids)),ids]=0
            ks=g.matched_k.to_numpy();assert ((B>0).sum(1)>=ks).all()
            rank=np.argsort(-np.where(B>0,np.round(B,12),-np.inf),axis=1,kind='stable')[:,:20]
            val=(np.take_along_axis(T,rank,axis=1)*(np.arange(20)[None,:]<ks[:,None])).sum(1)
            if model=='task':np.testing.assert_allclose(val,g.task,atol=1e-10,rtol=0)
            if model=='random':random_sum[ds]+=val/repeats
            else:
                details.extend(dict(dataset=ds,origin=o,model=model,recovery=v,onet=n) for o,v,n in zip(g.origin,val,g.onet_published))
            results.append(dict(dataset=ds,model=model,draw=draw,n=len(g),mean=val.mean()))
    evaluate(M,'task')
    links=pd.read_csv(bridge_path);B=metrics.fractional_bridge(task_ids,sorted(links.dwa_id.unique()),links.itertuples(index=False,name=None)).tocsr()
    mass=np.asarray(M.sum(0)).ravel();B=(sparse.diags((mass>0).astype(float))@B).tocsr()
    B=B[:,np.asarray((M@B).sum(0)).ravel()>0].tocsr();degree=np.diff(B.indptr);mapped=degree>0
    evaluate(M@B,'dwa');evaluate(M.multiply(mapped),'mapped_tasks')
    mi=np.flatnonzero(mapped);order=mi[np.argsort(mass[mi],kind='stable')];dec=np.zeros(len(task_ids),dtype=int);dec[order]=np.arange(len(order))*10//len(order)
    strata={}
    for i in mi:strata.setdefault((int(degree[i]),int(dec[i])),[]).append(i)
    sets=[np.array(s) for s in strata.values() if len(s)>1]
    for draw in range(repeats):
        rng=np.random.default_rng(20262015+draw);perm=np.arange(len(task_ids))
        for st in sets:perm[st]=rng.permutation(st)
        Q=B[perm,:];assert np.array_equal(np.diff(Q.indptr),degree)
        np.testing.assert_allclose(np.asarray(Q.sum(0)),np.asarray(B.sum(0)),atol=1e-10)
        assert np.array_equal(dec[perm][mapped],dec[mapped])
        evaluate(M@Q,'random',draw)
    for ds,(_,_,_,g) in prep.items():
        if repeats:
            details.extend(dict(dataset=ds,origin=o,model='random',recovery=v,onet=n) for o,v,n in zip(g.origin,random_sum[ds],g.onet_published))
        details.extend(dict(dataset=ds,origin=o,model='onet',recovery=n,onet=n) for o,n in zip(g.origin,g.onet_published))
    detail=pd.DataFrame(details);res=pd.DataFrame(results)
    summary=detail.groupby(['dataset','model']).agg(mean=('recovery','mean'),n=('origin','size')).reset_index()
    detail.to_csv(out/'aggregation_by_origin.csv',index=False);res.to_csv(out/'aggregation_draws.csv',index=False)
    summary.to_csv(out/'figure_representation_summary.csv',index=False)
    pd.DataFrame([dict(active_dwas=B.shape[1],mapped_tasks=int(mapped.sum()),positive_tasks=int((mass>0).sum()),mapped_mass_share=mass[mapped].sum()/mass.sum(),repeats=repeats,first_seed=20262015)]).to_csv(out/'aggregation_coverage.csv',index=False)
    return summary
