# Task-linked skills and abilities: paper-aligned validation

Run `python3 replicate.py` after extracting the package (requires pandas).
Outputs go to `results/`: summary, per-origin results, and a recommendation audit.

For each origin, derive k = min(20, paper task-list length, published O*NET-list
length) from paper_rankings.csv. Apply exactly that k to all six representations.
The program fails if a model cannot supply k destinations; it does not silently
change the budget or population. Outcome denominators remain unchanged and each
origin receives equal weight. SST measures original transition-share capture;
EMSI assigns mass 1/20 to each original benchmark destination.

The rankings are frozen from the task/skill/ability construction experiment.
This reruns validation, not sampling, extraction, profile construction, or
model fitting. Fixed equal-rank combinations are included. The separate
training-selected hybrid experiment has not been re-estimated here and remains
explicitly labeled as an older up-to-20 sensitivity analysis.

expected_summary.csv is a verification target only. The main task and O*NET
predictions, budgets, and outcomes were checked for all 1,033 SST/EMSI origins
against the paper replication package. No task profiles or posting records are
included. Sources: SST public occupational mobility data and the Department of
Labor Career Transitions Dashboard (EMSI); published O*NET related occupations.
