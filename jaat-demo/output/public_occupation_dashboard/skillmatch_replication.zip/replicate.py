"""Recalculate paired SkillMatch validation from frozen occupational rankings.

Run: python3 replicate.py [directory containing this script]
Standard library only. No database, posting records, or feature vectors needed.
This reproduces validation, not extraction or profile construction.
"""
import csv, gzip, json, math, sys
from collections import defaultdict
from pathlib import Path

MODELS = ('task', 'skill', 'combined', 'onet_published')

def calculate(root):
    # Rankings contain at most 20 positive-score, non-self destinations per model.
    lists = defaultdict(lambda: {m: [] for m in MODELS})
    with gzip.open(root / 'rankings.csv.gz', 'rt') as f:
        rows = sorted(csv.DictReader(f), key=lambda r: (r['dataset'], r['origin'], r['model'], int(r['rank'])))
    for r in rows:
        lists[r['dataset'], r['origin']][r['model']].append(r['destination'])
    outcomes = json.loads((root / 'outcomes.json').read_text())
    origins = []
    for (dataset, origin), models in sorted(lists.items()):
        # Same length for all four models. Keep the original outcome denominator.
        k = min(20, *(len(v) for v in models.values()))
        if not k:
            continue
        truth = outcomes[dataset]['truth'][origin]
        denominator = outcomes[dataset]['denominators'][origin]
        captures = {m: sum(truth.get(d, 0) for d in destinations[:k]) / denominator
                    for m, destinations in models.items()}
        for model in MODELS:
            origins.append(dict(dataset=dataset, origin=origin, model=model, matched_k=k,
                                capture=captures[model], difference_from_onet=captures[model]-captures['onet_published']))
    summary = []
    for dataset in outcomes:
        for model in MODELS:
            rs = [r for r in origins if r['dataset'] == dataset and r['model'] == model]
            if not rs:
                continue
            n = len(rs)
            higher = sum(r['difference_from_onet'] > 1e-12 for r in rs)
            summary.append(dict(dataset=dataset, model=model, origins=n,
                mean_k=sum(r['matched_k'] for r in rs)/n,
                mean_capture=sum(r['capture'] for r in rs)/n,
                origins_higher_than_onet=higher, share_higher_than_onet=higher/n))
    return origins, summary

if __name__ == '__main__':
    root = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    origins, summary = calculate(root)
    expected = {(r['dataset'],r['model']):r for r in csv.DictReader((root/'expected_summary.csv').open())}
    assert set(expected) == {(r['dataset'],r['model']) for r in summary}
    for r in summary:
        for key, value in r.items():
            if key not in ('dataset','model'):
                assert math.isclose(value,float(expected[r['dataset'],r['model']][key]),abs_tol=1e-12,rel_tol=0),(r,key)
    for name, rows in [('recomputed_by_origin.csv',origins),('recomputed_summary.csv',summary)]:
        with (root/name).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(f'PASS: {len(summary)} model–benchmark summaries; {len(origins)} model–origin comparisons.')
