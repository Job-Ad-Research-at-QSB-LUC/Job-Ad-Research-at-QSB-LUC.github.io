# SkillMatch paired-sample validation

Run `python3 replicate.py` after extracting this ZIP. Python standard library only.
The script recomputes equal-length capture and the share of origins with more capture
than O*NET, for four models and six benchmark definitions. Expected results are used
only to check the calculations, never as calculation inputs. Output denominators
are retained in full. Origins receive equal weight.

Inputs are frozen aggregate rankings and occupational transition outcomes. No
posting identifiers or task/skill profiles are included. This package reproduces
validation conditional on those rankings, not the database extraction. profile_math.py
provides the original sampling allocation, incidence aggregation, square-root RCA,
cosine pooling, ranking, and evaluation functions (requires numpy). Full model
reconstruction additionally requires restricted posting data and extraction outputs,
task-review exclusions, and occupation crosswalks. See the page's methods.

Source outcomes: Schubert, Stansbury and Taska occupational mobility data; Department
of Labor Career Transitions Dashboard (EMSI, CPS, SIPP, NLSY97, PSID). O*NET published
related occupations are from O*NET 31.0. O*NET data are CC BY 4.0.
