"""Pure numerical/statistical operations; no database or filesystem side effects."""
import math
from collections import defaultdict, Counter
import numpy as np

MONTHS=['2024-10','2024-11','2024-12']+[f'2025-{m:02}' for m in range(1,10)]

def allocate(counts,rate=.1,floor=200):
    if not 0<rate<=1 or floor<1:raise ValueError('Invalid sampling settings')
    counts={k:int(v) for k,v in counts.items() if v>0}
    if not counts:return {}
    n=sum(counts.values());target=min(n,max(math.ceil(rate*n),floor,len(counts)))
    if target==n:return counts.copy()
    quota={k:(target-len(counts))*(v-1)/(n-len(counts)) for k,v in counts.items()}
    out={k:1+math.floor(v) for k,v in quota.items()}
    for k in sorted(counts,key=lambda k:(-(quota[k]%1),k))[:target-sum(out.values())]:out[k]+=1
    return out

def aggregate_jobs(jobs,weights):
    """One row per sampled job: occ,id,task IDs,skill IDs,task-row seen,skill-row seen."""
    counts=defaultdict(lambda:[0,0.]);coverage=defaultdict(Counter)
    for occ,job,tasks,skills,task_seen,skill_seen in jobs:
        tasks=set(tasks);skills=set(skills);w=float(weights[occ]);c=coverage[occ]
        c['sample_jobs']+=1;c['weighted_jobs']+=w
        c['task_missing_rows']+=not task_seen;c['skill_missing_rows']+=not skill_seen
        c['task_empty_rows']+=task_seen and not tasks;c['skill_empty_rows']+=skill_seen and not skills
        c['task_nonempty']+=bool(tasks);c['skill_nonempty']+=bool(skills)
        paired=bool(tasks and skills);c['paired_jobs']+=paired;c['weighted_paired_jobs']+=w*paired
        for model,ids in [('all_task',tasks),('all_skill',skills),('paired_task',tasks if paired else []),('paired_skill',skills if paired else [])]:
            for feature in ids:
                a=counts[(model,occ,str(feature))];a[0]+=1;a[1]+=w
    return dict(counts),dict(coverage)

def profiles(counts,model,min_support=5,excluded=frozenset()):
    retained={(o,f):float(w) for (m,o,f),(n,w) in counts.items() if m==model and n>=min_support and w>0 and (o,f) not in excluded}
    codes=sorted({o for o,f in retained});features=sorted({f for o,f in retained})
    oi={o:i for i,o in enumerate(codes)};fi={f:i for i,f in enumerate(features)}
    x=np.zeros((len(codes),len(features)),dtype=np.float64)
    for (o,f),w in retained.items():x[oi[o],fi[f]]=w
    if x.size:
        p=x.sum(axis=0)/x.sum();q=x/x.sum(axis=1,keepdims=True)
        x=np.sqrt(q/p);x/=np.linalg.norm(x,axis=1,keepdims=True)
    return codes,features,x

def rank(codes,scores,origin):
    values={c:float(s) for c,s in zip(codes,scores) if c!=origin and np.isfinite(s) and s>0}
    return sorted(values,key=lambda c:(-round(values[c],12),c))[:20]

def evaluate(lists,truth,denominator):
    if not np.isfinite(denominator) or denominator<=0:raise ValueError('Invalid outcome denominator')
    if any(len(v)!=len(set(v)) for v in lists.values()):raise ValueError('Duplicate destinations')
    k=min([20]+[len(v) for v in lists.values()])
    return {'k':k,'captures':{m:sum(truth.get(d,0) for d in v[:k])/denominator for m,v in lists.items()}}

def pool(codes,vectors,groups):
    """Mean specialty vectors; do NOT renormalize (mean pairwise cosine)."""
    ix={c:i for i,c in enumerate(codes)}
    valid={str(c):members for c,members in groups.items() if members and all(s in ix for s in members)}
    return sorted(valid),np.array([vectors[[ix[s] for s in valid[c]]].mean(axis=0) for c in sorted(valid)])
