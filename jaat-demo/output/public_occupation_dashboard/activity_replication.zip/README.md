# Activities and soft cosine, equal-length validation

Run `python3 replicate.py` (requires pandas). This independently evaluates the
frozen aggregate recommendations, derives each origin's cutoff from the paper's
task and published O*NET lists, and writes results/summary.csv, by_origin.csv,
and recommendation_audit.csv.gz. All models must return the required length.
All original outcome denominators remain; origins receive equal weight.

build.py records full research construction; it requires the original project,
restricted weighted task incidence, crosswalks and benchmark inputs, and numpy,
pandas and scipy. It does not run from this aggregate package alone.
DWA/IWA use frozen production RCA profiles. GWA is newly constructed by splitting
each task's weighted mass equally among distinct GWA links, then applying pooled
RCA, square roots, L2 normalization, and cosine, as in DWA/IWA.

Soft cosine retains the original task RCA vectors. Let B be a binary task-to-DWA
matrix with each nonempty task row normalized to length one. Its kernel is
S = I + alpha * (B B' - diag(mapped)). Exact self-similarity is one, unrelated
tasks receive zero, and different tasks receive alpha times cosine overlap of
DWA links. Unmapped tasks retain identity. This kernel is positive semidefinite
for the tested alpha values. Normalize V S V' by its diagonal, then average
specialty-pair scores into the same benchmark groups as the paper.

Alpha .10 is highlighted after inspecting .10, .25, and .50 on these benchmarks.
This is exploratory selection, not held-out improvement or significance evidence.
All tested settings are included. The paper's original task model is unchanged.
The package contains aggregate occupational rankings/outcomes, not task profiles
or posting records. Sources: O*NET task/activity links, SST occupational mobility
data, and Department of Labor Career Transitions Dashboard.
