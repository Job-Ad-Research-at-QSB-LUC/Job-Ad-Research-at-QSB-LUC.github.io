"""Evaluate task-linked representations at the paper's per-origin list length (activities and soft cosine).
Run: python3 replicate.py [input folder] [output folder]. Requires pandas.
Inputs are aggregate occupational rankings and outcomes, not posting records.
"""
from pathlib import Path
import sys
import pandas as pd

MODELS=['task','dwa','iwa','gwa','soft_0.1','soft_0.25','soft_0.5']

def calculate(rankings, paper_rankings, observed, origins):
    keys=['dataset','origin']
    assert not rankings.duplicated(keys+['model','destination']).any()
    assert not rankings.duplicated(keys+['model','rank']).any()
    assert not observed.duplicated(keys+['destination']).any()
    assert not origins.duplicated(keys).any()
    assert set(rankings.model)==set(MODELS)
    # Determine the budget from the original paper's task and published O*NET
    # lists, without consulting transitions or alternative-model performance.
    lengths=paper_rankings.groupby(keys+['model']).size().unstack('model')
    budget=lengths[['task','onet_published']].fillna(0).min(axis=1).clip(upper=20).rename('matched_k')
    base=origins.merge(budget.reset_index(),on=keys,validate='one_to_one')
    assert len(base)==len(origins) and base.matched_k.gt(0).all()
    # Require every representation to supply that many destinations. Never
    # silently shorten only one model or change the paper's evaluation population.
    for model in MODELS:
        counts=rankings[rankings.model.eq(model)].groupby(keys).size()
        check=base.set_index(keys).join(counts.rename('returned'))
        assert check.returned.ge(check.matched_k).all(),model
    selected=rankings.merge(base,on=keys,validate='many_to_one')
    selected=selected[selected['rank'].le(selected.matched_k)].copy()
    audit=selected.merge(observed,on=keys+['destination'],how='left',validate='many_to_one')
    audit['mass']=audit.mass.fillna(0)
    audit['contribution']=audit.mass/audit.denominator
    by=audit.groupby(keys+['model'],as_index=False).agg(capture=('contribution','sum'),matched_k=('matched_k','first'),returned=('rank','size'))
    assert by.returned.eq(by.matched_k).all()
    summary=by.groupby(['dataset','model'],as_index=False).agg(origins=('origin','size'),mean_k=('matched_k','mean'),mean_capture=('capture','mean'))
    return by,summary,audit

def run(folder,out):
    frames=[pd.read_csv(folder/n,dtype={'origin':str,'destination':str}) for n in ['rankings.csv.gz','paper_rankings.csv','observed.csv','origins.csv']]
    by,summary,audit=calculate(*frames)
    out.mkdir(parents=True,exist_ok=True)
    by.to_csv(out/'by_origin.csv',index=False);summary.to_csv(out/'summary.csv',index=False)
    audit.to_csv(out/'recommendation_audit.csv.gz',index=False)
    # The saved reference is verification only, never an input to the calculation.
    expected=folder/'expected_summary.csv'
    if expected.exists():
        ref=pd.read_csv(expected).set_index(['dataset','model']).sort_index()
        actual=summary.set_index(['dataset','model']).sort_index()
        assert actual.index.equals(ref.index)
        assert (actual-ref).abs().max().max()<1e-12
    print(summary.to_string(index=False))
    return by,summary

if __name__=='__main__':
    folder=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
    run(folder,Path(sys.argv[2]) if len(sys.argv)>2 else folder/'results')
