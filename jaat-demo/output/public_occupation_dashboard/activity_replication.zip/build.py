import sys,importlib.util,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy import sparse
P=Path(__file__).resolve().parent;R=P.parents[1];A=R/'analysis/relatedness_refresh_20260922'
sys.path.insert(0,str(R/'analysis/occupation_relatedness'))
from metrics import representation,cosine_matrix,fractional_bridge
spec=importlib.util.spec_from_file_location('cross_inputs',R/'analysis/onet_currency_20260928/cross_group/analyze.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mats,data=m.getinputs();sp,baseline=mats['task'];si={s:i for i,s in enumerate(sp)}
codes=pd.read_csv(A/'atlas_data/relatedness/occupation_coverage.csv').occupational_code.tolist()
tids=pd.read_csv(R/'analysis/occupation_relatedness/results/task_matrix_columns.csv').task_id.tolist();ti={t:i for i,t in enumerate(tids)}
X=sparse.load_npz(A/'atlas_data/relatedness/supported_weighted_task_counts.npz')
w=pd.read_csv(A/'results/task_rca_feature_weights.csv').rca_weight.to_numpy();_,V=representation(X,w)
idx={c:i for i,c in enumerate(codes)};V=V[[idx[c] for c in sp]]
base=(V@V.T).toarray();assert np.max(abs(base-baseline))<1e-10
links=pd.read_csv(R/'crosswalks/onet_tasks_to_dwas.txt',sep='\t',usecols=['Task ID','DWA ID']).drop_duplicates();links=links[links['Task ID'].isin(ti)]
features=sorted(links['DWA ID'].unique());fi={f:i for i,f in enumerate(features)}
B=sparse.csr_matrix((np.ones(len(links)),(links['Task ID'].map(ti),links['DWA ID'].map(fi))),shape=(len(tids),len(features)))
degree=np.asarray(B.sum(axis=1)).ravel();mapped=degree>0
B=sparse.diags(np.divide(1,np.sqrt(degree),out=np.zeros_like(degree),where=mapped))@B
# Soft-cosine kernel S=I + alpha*(B B' - diag(mapped)).
# Each task's self similarity stays 1. Different tasks receive partial credit
# according to cosine overlap of their DWA links. Unmapped tasks retain identity.
# For 0<=alpha<=1 this is positive semidefinite.
VB=V@B;shared=(VB@VB.T).toarray();exact_mapped=(V[:,mapped]@V[:,mapped].T).toarray()
refs=pd.read_csv(R/'analysis/validation_replication/by_origin.csv',dtype={'origin':str});refs=refs[refs['mode'].eq('equal_length')].set_index(['dataset','origin'])
# Construct GWA using the same fractional allocation and pooled RCA rule.
links['GWA']=links['DWA ID'].str.rsplit('.',n=2).str[0]
gwas=sorted(links.GWA.unique())
F=fractional_bridge(tids,gwas,links[['Task ID','GWA']].drop_duplicates().itertuples(index=False,name=None))
M=X@F;tot=np.asarray(M.sum(0)).ravel();p=tot/tot.sum();weights=np.divide(1,p,out=np.zeros_like(p),where=p>0)
_,gv=representation(M,weights);gwa=cosine_matrix(gv)[np.ix_([idx[c] for c in sp],[idx[c] for c in sp])]
sims={'task':baseline,'gwa':gwa}
for model in ['dwa','iwa']:
    cs,sm=mats[model];ix={c:i for i,c in enumerate(cs)};sims[model]=sm[np.ix_([ix[c] for c in sp],[ix[c] for c in sp])]
for alpha in [.1,.25,.5]:
    numerator=base+alpha*(shared-exact_mapped)
    norm=np.sqrt(np.diag(numerator));denom=norm[:,None]*norm[None,:]
    sims['soft_'+str(alpha)]=np.divide(numerator,denom,out=np.zeros_like(numerator),where=denom>0)
by=[];rankings=[]
for model,sim in sims.items():
    assert np.isfinite(sim).all() and np.max(sim)<=1+1e-10
    for ds,(groups,origins,truth,_) in data.items():
        original=sorted(groups);cs=np.array([str(c) for c in original]);ci={c:i for i,c in enumerate(cs)}
        G=np.zeros((len(cs),len(sp)))
        for i,c in enumerate(original):G[i,[si[s] for s in groups[c]]]=1/len(groups[c])
        scores=G@sim@G.T
        for o0 in origins:
            o=str(o0);row=scores[ci[o]];ref=refs.loc[ds,o];k=int(ref.matched_k)
            js=np.flatnonzero((row>0)&(cs!=o));js=js[np.argsort(-np.round(row[js],12),kind='stable')][:k];assert len(js)==k
            tr={str(d):float(v) for d,v in truth[o0].items()};den=1 if ds in ['SST','Emsi'] else sum(tr.values())
            value=sum(tr.get(d,0) for d in cs[js])/den
            if model=='task':assert abs(value-ref.task)<1e-10,(ds,o)
            by.append(dict(dataset=ds,origin=o,model=model,k=k,capture=value,baseline=ref.task,delta_pp=100*(value-ref.task)))
            for rank,dest in enumerate(cs[js],1):rankings.append(dict(dataset=ds,origin=o,model=model,destination=dest,rank=rank))
    print('Finished',model,flush=True)
d=pd.DataFrame(by);d.to_csv(P/'by_origin.csv',index=False)
d.groupby(['dataset','model'],as_index=False).agg(origins=('origin','size'),mean_k=('k','mean'),mean_capture=('capture','mean')).to_csv(P/'expected_summary.csv',index=False)
s=d.groupby(['dataset','model'],sort=False).agg(origins=('origin','size'),mean_capture=('capture','mean'),delta_pp=('delta_pp','mean')).reset_index();s.to_csv(P/'summary.csv',index=False)
pd.DataFrame(rankings).to_csv(P/'rankings.csv.gz',index=False,compression={'method':'gzip','mtime':0})
print(s.to_string(index=False))
(P/'checks.json').write_text(json.dumps({'baseline_all_origins_matches':True,'mapped_tasks':int(mapped.sum()),'total_tasks':len(tids),'GWA_features':len(gwas),'DWA_features':len(features),'kernel':'I + alpha*(B Btranspose - diag(mapped))','alphas':[.1,.25,.5]},indent=2))
