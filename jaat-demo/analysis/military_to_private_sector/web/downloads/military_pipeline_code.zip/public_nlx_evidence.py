"""Filter only NLx assignment explanations; public military coding is unrestricted."""
from pathlib import Path
from functools import lru_cache
import sys,copy
P=Path(__file__).resolve().parent
@lru_cache(maxsize=1)
def allowed():
 sys.path.insert(0,str(P.parent/'dashboard_release'))
 from build_public import SOURCE,read_js,coordinated_allowed
 catalog=read_js(SOURCE/'occupation_network_data/catalog.js')
 profiles={p.stem:read_js(p) for p in (SOURCE/'occupation_network_data/occupations').glob('*.js')}
 return coordinated_allowed(profiles,catalog['tasks'])
def shared(tasks,soc):return [t for t in tasks if int(t['task_id']) in allowed().get(soc,set())]
def public_pathways(rows):
 rows=copy.deepcopy(rows)
 for r in rows:
  old=r['shared_tasks'];r['shared_tasks']=shared(old,r['soc']);r['withheld_shared_task_count']=len(old)-len(r['shared_tasks'])
  r['public_evidence_note']='NLx identities/contributions follow coordinated public occupation permissions; shown contributions are partial and not renormalized. Government source coding remains unrestricted. Full score/rank uses all retained research features.'
  r.pop('source_group_ablation',None)
  r.pop('duty_family_ablation',None)
  r['source_group_ablation_note']='Task-specific source-group ablations are retained in the research outputs; withheld publicly because they can disclose restricted NLx assignment identities. They do not establish independent duty-family robustness.'
 return rows
