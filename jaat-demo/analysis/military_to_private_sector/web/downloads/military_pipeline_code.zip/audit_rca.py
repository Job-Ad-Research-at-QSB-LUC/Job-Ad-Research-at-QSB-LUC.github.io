"""Independent dense reconstruction of pilot military-to-pooled-SOC6 RCA scores."""
from pathlib import Path
import hashlib,json,zipfile
import numpy as np
import pandas as pd
P=Path(__file__).resolve().parent;ROOT=P.parents[1];O=P/'rca_20260930'
wpath=ROOT/'analysis/relatedness_refresh_20260922/results/task_rca_feature_weights.csv'
w=pd.read_csv(wpath);ids=w.unit_id.astype(str).tolist();ix={t:i for i,t in enumerate(ids)}
observed=w.corpus_task_share.gt(0)
assert np.allclose(w.loc[observed,"corpus_task_share"]*w.loc[observed,"rca_weight"],1)
assert w.loc[~observed,"rca_weight"].eq(0).all()
a=pd.read_csv(ROOT/'data/release/occupation_task_marginals.csv.gz')
mask=pd.read_csv(ROOT/'analysis/relatedness_refresh_20260922/applied/exclusion_mask.csv')
a=a[~pd.MultiIndex.from_frame(a[['occupational_code','task_id']]).isin(pd.MultiIndex.from_frame(mask[['occ8','task_id']]))]
a=a[a.n_jobs_with_task.ge(5)&a.task_id.astype(str).isin(ix)];a['soc']=a.occupational_code.str[:7]
saved=np.load(P/'outputs/nlx_crosswalk/all_scores_soc6.npz');codes=list(saved['codes']);ci={c:i for i,c in enumerate(codes)}
a=a[a.soc.isin(ci)];x=np.zeros((len(codes),len(ids)))
np.add.at(x,(a.soc.map(ci),a.task_id.astype(str).map(ix)),a.weighted_jobs_with_task)
def norm(x):
 q=x/x.sum(axis=-1,keepdims=True);v=np.sqrt(q*w.rca_weight.to_numpy());return v/np.linalg.norm(v,axis=-1,keepdims=True)
v=norm(x)
coded={d['doc_id']:d for d in map(json.loads,(P/'outputs/coded_documents.jsonl').read_text().splitlines())}
rows=json.loads((P/'outputs/pathway_review/reviewed_pathways.json').read_text())
checks=[]
for doc in sorted({r['doc_id'] for r in rows}):
 m=np.zeros(len(ids));m[[ix[t] for t in {str(z[0]) for z in coded[doc]['task']['matches']} if t in ix]]=1
 expected=norm(m)@v.T;actual=saved['scores'][list(saved['doc_ids']).index(doc)]
 error=float(np.max(abs(expected-actual)));assert error<1e-12
 checks.append({'doc_id':doc,'max_score_error':error})
with zipfile.ZipFile(O/'before.zip') as z:old=json.loads(z.read('outputs/pathway_review/reviewed_pathways.json'))
assert {(r['doc_id'],r['soc']) for r in old}<={(r['doc_id'],r['soc']) for r in rows}
assert len({(r['doc_id'],r['soc']) for r in rows})==len(rows)
for r in rows:
 assert abs(sum(t['contribution'] for t in r['shared_tasks'])-r['reviewed_cosine'])<1e-12
 body=next(d['body'] for d in map(json.loads,(P/'inputs/descriptions.jsonl').read_text().splitlines()) if d['doc_id']==r['doc_id'])
 assert all(q in body for t in r['shared_tasks'] for q in t['quotes'])
assert sum(r['status']=='Documented correspondence' for r in rows)==11
assert not any(r['status']=='Supported extension' for r in rows)
manifest=json.loads((P/'outputs/nlx_crosswalk/manifest.json').read_text())
assert manifest['input_hashes']['rca_weights']==hashlib.sha256(wpath.read_bytes()).hexdigest()
for name,digest in json.loads((O/'native_input_hashes.json').read_text()).items():
 assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest
result={'status':'passed','independent_dense_score_reconstruction':checks,'reference_weight_sha256':manifest['input_hashes']['rca_weights'],'pilot_candidates':len(rows),'documented':11,'supported':0,'all_prior_candidates_retained':True,'source_and_coding_unchanged':True}
(P/'outputs/pathway_review/verification.json').write_text(json.dumps({'result':'PASS','candidates':len(rows),'checks':['unique doc/SOC pairs','RCA shared-task contributions sum to reviewed cosine','all source quotations verbatim in coding body','11 documented correspondences and zero supported upgrades','all prior candidates retained','independent dense reconstruction of raw RCA scores']},indent=2))
(O/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
