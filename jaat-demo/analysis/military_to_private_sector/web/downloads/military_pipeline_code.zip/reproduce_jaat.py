"""Re-run frozen native coding using the recorded Hugging Face revisions.
Run from a fresh installed environment. Downloads only official model artifacts.
Writes outputs/reproduced; preserves the supplied results.
"""
from pathlib import Path
import json,hashlib,os
os.environ.pop('HF_HUB_OFFLINE',None)
from huggingface_hub import snapshot_download
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'outputs/run_manifest.json').read_text())
assert hashlib.sha256((ROOT/'inputs/descriptions.jsonl').read_bytes()).hexdigest()==manifest['input_sha256'],'Inputs differ from the supplied run; preserve frozen inputs for exact reproduction'
import importlib.metadata
for package,version in manifest['versions'].items():
 assert importlib.metadata.version(package)==version,f'Install the recorded {package} version: {version}'
for name,digest in manifest['code_sha256'].items():
 assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,f'Code differs: {name}'
import importlib.resources
inventory=json.loads((ROOT/'outputs/native_inventory_manifest.json').read_text())
for name,info in inventory.items():
 h=hashlib.sha256()
 with (importlib.resources.files('JAAT.data')/name).open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 assert h.hexdigest()==info['sha256'],f'JAAT reference inventory differs: {name}'
title_manifest=json.loads((ROOT/'outputs/title_correction_manifest.json').read_text())
assert hashlib.sha256((ROOT/'refine_titles.py').read_bytes()).hexdigest()==title_manifest['script_sha256'],'Title correction code differs'
revisions={'thenlper/gte-small':manifest['embedding_revision'],'loyoladatamining/task-classifier-mini-v3':manifest['classifier_revision'],**manifest['title_models']}
resolved={repo:(snapshot_download(repo_id=repo,revision=revision),revision) for repo,revision in revisions.items()}
# Native TitleMatch hardcodes repository IDs. Use an isolated cache containing
# the requested revisions; no user cache pointers are overwritten.
import shutil
cache=ROOT/'model_cache';cache.mkdir(exist_ok=True)
for repo,(path,revision) in resolved.items():
 base=cache/('models--'+repo.replace('/','--'));(base/'snapshots').mkdir(parents=True,exist_ok=True);(base/'refs').mkdir(exist_ok=True)
 target=base/'snapshots'/revision
 if not target.exists():shutil.copytree(path,target)
 (base/'refs/main').write_text(revision)
os.environ['HF_HUB_CACHE']=str(cache)
os.environ['HF_HUB_OFFLINE']='1'
# Launch in a fresh process so Transformers sees the isolated cache at import.
import subprocess,sys
script="""import run_jaat
from pathlib import Path
import json
r=json.loads((run_jaat.ROOT/'outputs/run_manifest.json').read_text())
rev={'thenlper/gte-small':r['embedding_revision'],'loyoladatamining/task-classifier-mini-v3':r['classifier_revision'],**r['title_models']}
run_jaat.model_path=lambda repo:(str(run_jaat.ROOT/'model_cache'/('models--'+repo.replace('/','--'))/'snapshots'/rev[repo]),rev[repo])
run_jaat.OUT=run_jaat.ROOT/'outputs/reproduced';run_jaat.OUT.mkdir(exist_ok=True)
run_jaat.main()
import os,refine_titles
os.environ['MILITARY_OUTPUT_DIR']=str(run_jaat.OUT)
refine_titles.main()
"""
subprocess.run([sys.executable,'-c',script],cwd=ROOT,check=True)
