"""Check military public exports against coordinated civilian disclosure policy."""
from pathlib import Path
import json,zipfile,hashlib
from public_nlx_evidence import allowed
P=Path(__file__).resolve().parent;W=P/'web';D=W/'downloads'
def main():
 permits=allowed();checked=0
 from build_public import OUTPUT,read_js
 for code,ids in permits.items():
  published=OUTPUT/'occupation_network_data/occupations'/f'{code}.js'
  assert set(read_js(published)['public_allowed_ids'])==ids,code
 for p in (W/'data').glob('*.json'):
  d=json.loads(p.read_text())
  if not isinstance(d,dict):continue
  for v in d.get('nlx_crosswalk',{}).values():
   for r in v['top20']:
    assert all(int(t['task_id']) in permits.get(r['soc'],set()) for t in r['shared_tasks']),(p,r['soc'])
    checked+=len(r['shared_tasks'])
 rows=json.loads((D/'reviewed_military_pathways.json').read_text())
 for r in rows:
  assert 'source_group_ablation' not in r and 'duty_family_ablation' not in r
  assert all(int(t['task_id']) in permits.get(r['soc'],set()) for t in r['shared_tasks'])
  assert len(r['shared_tasks'])+r['withheld_shared_task_count']==r['shared_task_count']
 with zipfile.ZipFile(D/'military_pathway_pilot.zip') as z:
  assert 'outputs/pathway_review/candidates.json' not in z.namelist()
  assert json.loads(z.read('outputs/pathway_review/reviewed_pathways.json'))==rows
 with zipfile.ZipFile(D/'military_repair_evidence.zip') as z:
  assert not any(n.endswith(('candidates.json','reviewed_pathways.json')) for n in z.namelist())
 manifest=json.loads((D/'manifest.json').read_text())
 assert {p.name for p in D.iterdir() if p.is_file() and p.name!='manifest.json'}==set(manifest)
 for name,m in manifest.items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==m['sha256'],name
 result={'status':'passed','public_nlx_contributions_checked':checked,'public_pilot_candidates':len(rows),'public_pilot_withheld_identities':sum(r['withheld_shared_task_count'] for r in rows),'government_source_coding':'unrestricted','public_download_allowlist':sorted(manifest),'policy':'build_public.coordinated_allowed; partial explanations, full scores/ranks. No task-specific ablations or unfiltered pilot candidate JSON in public archives.'}
 (P/'repair_20260929/public_audit.json').write_text(json.dumps(result,indent=2));print(result)
if __name__=='__main__':main()
