"""Bounded, evidence-reviewed pilot. Uses refreshed RCA scores and benchmark provider lists; native JAAT coding is preserved."""
from pathlib import Path
import sys,json,hashlib,html,zipfile,re
import numpy as np,pandas as pd
from scipy import sparse
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
sys.path.insert(0,str(ROOT/'analysis/occupation_relatedness'))
from metrics import representation
OUT=P/'outputs/pathway_review';OUT.mkdir(exist_ok=True)
# Conservative task-level sensitivity: retain a task only when at least one
# source quotation supports its core action and domain. Not a new JAAT run.
ACCEPT={
'army_15R_0060':{'14930','9948','9967','9971','9949','10881','3076','14902','14286','2927','10728','21316'},
'marines_4422_0629':{'8654','8655','22890'},
'navy_002779_0212':{'1319','15465','21780','21087','17614','15649','1301','21612','2712','20785','11658','21781','21458','22944','21771','21290','21500','21775','17567','18965','18968','16424','18993','18972','22011','21984','21291','18960','23006'}
}
EXCLUSION_REASONS={
 '21298':'Identifying security issues and validating remediation do not establish identification, investigation, or resolution of an actual security breach.',
 '21774':'Implementing vulnerability remediation does not establish developing response and recovery strategies for security breaches; both action and domain differ.',
 '14648':'Verifying execution and documentation of tests does not establish authoring test procedures for replicability and standards compliance.',
 '3483':'Evaluating cost-benefit/economic/risk analyses does not establish preparing cost-benefit and return-on-investment analyses.'}
with zipfile.ZipFile(P/'repair_20260929/before.zip') as z:
 prior_candidates=json.loads(z.read('outputs/pathway_review/candidates.json'))
 prior_decisions=json.loads(z.read('outputs/pathway_review/task_review.json'))
prior_candidates += json.loads((P/'rca_20260930/prior_candidate_keys.json').read_text())
paths={'marginals':ROOT/'data/release/occupation_task_marginals.csv.gz','totals':ROOT/'data/release/occupation_totals.csv','mask':ROOT/'analysis/relatedness_refresh_20260922/applied/exclusion_mask.csv','rca_weights':ROOT/'analysis/relatedness_refresh_20260922/results/task_rca_feature_weights.csv','columns':ROOT/'analysis/occupation_relatedness/results/task_matrix_columns.csv','cool':P/'reference/cool_supplemental_data.xlsx'}
tids=pd.read_csv(paths['columns']).task_id.astype(str).tolist();ti={t:i for i,t in enumerate(tids)}
w=pd.read_csv(paths['rca_weights']);assert w.unit_id.astype(str).tolist()==tids;rca_weight=w.rca_weight.to_numpy();assert np.isfinite(rca_weight).all() and (rca_weight >= 0).all()
a=pd.read_csv(paths['marginals']);mask=pd.read_csv(paths['mask']);blocked=pd.MultiIndex.from_frame(mask[['occ8','task_id']]);a=a[~pd.MultiIndex.from_frame(a[['occupational_code','task_id']]).isin(blocked)];a=a[a.n_jobs_with_task.ge(5)&a.task_id.astype(str).isin(ti)]
a['soc']=a.occupational_code.str[:7];tot=pd.read_csv(paths['totals']);tot=tot.groupby(tot.occupational_code.str[:7]).n_jobs.sum();codes=sorted(c for c in tot[tot.ge(200)].index if not c.startswith('55-'));ci={c:i for i,c in enumerate(codes)};a=a[a.soc.isin(ci)]
x=sparse.csr_matrix((a.weighted_jobs_with_task,(a.soc.map(ci),a.task_id.astype(str).map(ti))),shape=(len(codes),len(tids)));keep=np.asarray(x.sum(1)).ravel()>0;x=x[keep];codes=np.array(codes)[keep];ci={c:i for i,c in enumerate(codes)};_,v=representation(x,rca_weight)
cool=pd.read_excel(paths['cool'],sheet_name='COOL Supplemental Links',dtype=str).fillna('')
labels=pd.read_csv(ROOT/'analysis/occupation_relatedness/results/occupation_coverage.csv');names={c:' / '.join(sorted(set(g.occupation_title))) for c,g in labels.groupby(labels.occupational_code.str[:7])};names.update({r.occupational_code[:7]:r.occupation_title for r in labels.itertuples() if r.occupational_code.endswith('.00')})
paths['rca_prior_candidate_keys']=P/'rca_20260930/prior_candidate_keys.json'
paths['representation_code']=ROOT/'analysis/occupation_relatedness/metrics.py'
paths['raw_scores']=P/'outputs/nlx_crosswalk/all_scores_soc6.npz'
for doc in ACCEPT:paths[doc]=P/'web/data'/f'{doc}.json'
rawsaved=np.load(paths['raw_scores']);assert list(rawsaved['codes'])==list(codes)
def vec(ts):
 cols=[ti[t] for t in ts if t in ti];m=sparse.csr_matrix((np.ones(len(cols)),([0]*len(cols),cols)),shape=(1,len(tids)));return representation(m,rca_weight)[1]
def scores(ts):return np.asarray((vec(ts)@v.T).toarray()).ravel()
def rank(s,j):return int(np.sum(s>s[j]+1e-12)+1) if s[j]>0 else None
onet_path=ROOT/'analysis/relatedness_refresh_20260922/transition_validation/sources/onet_full_scores.csv.gz'
paths['onet_quantitative']=onet_path
oq=pd.read_csv(onet_path);oq['a']=oq.source.str[:7];oq['b']=oq.target.str[:7];onet=oq.groupby(['a','b']).score.mean().to_dict()
selection_path=OUT/'anchor_model_selection.json';paths['anchor_selection']=selection_path
selections=json.loads(selection_path.read_text())['anchors']
records=[];decisions=[]
for doc,accepted in ACCEPT.items():
 d=json.loads((P/'web/data'/f'{doc}.json').read_text());matches=d['coding']['matches'];quote_map={s['normalized_sentence']:s['source_quote'] for s in d['coding']['statements']};alltasks={str(m[0]) for m in matches};accepted=accepted&alltasks
 raw=scores(alltasks);assert np.allclose(raw,rawsaved['scores'][list(rawsaved['doc_ids']).index(doc)],atol=1e-10)
 reviewed=scores(accepted);mv=vec(accepted)
 for task in sorted(alltasks):
  ms=[m for m in matches if str(m[0])==task];decisions.append({'doc_id':doc,'task_id':task,'task':ms[0][1],'decision':'retain for sensitivity' if task in accepted else 'exclude from sensitivity','reason':(EXCLUSION_REASONS[task] if doc.startswith('navy') and task in EXCLUSION_REASONS else ('Provisional inherited sensitivity decision, not independently re-adjudicated: compare canonical task action/domain with the attached source quotes.' if task in accepted else 'Core action, domain, or specificity is not sufficiently established by the attached quotes; conservative exclusion, not necessarily a definite coding error.')),'quotes':[quote_map[m[2]] for m in ms]})
 refs=[r for r in d['reference_crosswalk']['rows'] if r['STATUS']=='A'];svc={'army':'A','marines':'M','navy':'N'}[d['branch']]
 cr=cool[(cool.Code==d['military_code'])&(cool.SVC==svc)&(cool.MPC=='E')]
 anchors=sorted({r[f'SOC{k}'] for r in refs for k in range(1,5) if r.get(f'SOC{k}') in ci})
 assert anchors
 anchor_scores=np.vstack([(v[ci[c]]@v.T).toarray().ravel() for c in anchors]);best=anchor_scores.max(0)
 candidates=set(np.argsort(-raw)[:20])|set(np.argsort(-reviewed)[:20])
 candidates.update(ci[r['soc']] for r in prior_candidates if r['doc_id']==doc and r['soc'] in ci)
 # Remove every accepted feature linked to a given source statement, including
 # features with additional supporting quotes. This deliberately over-removes.
 source_groups={}
 for match in matches:
  task=str(match[0])
  if task in accepted:source_groups.setdefault(quote_map[match[2]],set()).add(task)
 source_ablations=[(q,ts,scores(accepted-ts)) for q,ts in source_groups.items()]
 # Broad overlapping families intentionally remove correlated source duties.
 family_patterns={'security_policy_and_assurance':r'secur|vulnerab|accredit|access control|protection','network_operations_and_recovery':r'network|migration|disaster|recovery|technical support','resources_and_management':r'budget|staff|contract|personnel|resource|economic|cost.benefit'} if doc.startswith('navy') else {}
 family_ablations=[]
 for family,pattern in family_patterns.items():
  evidence=[q for q in source_groups if re.search(pattern,q,re.I)]
  ts=set().union(*(source_groups[q] for q in evidence)) if evidence else set()
  if ts:family_ablations.append((family,evidence,ts,scores(accepted-ts)))
 for anchor in anchors:
  selection=selections.get(anchor,{})
  candidates.update(ci[c] for c in selection.get('selected_top20',[]) if c in ci)
 refcodes=set(anchors)|{s[:7] for s in cr['O*NET-SOC Code']}
 candidates.update(ci[c] for c in refcodes if c in ci)
 for j in sorted(candidates,key=lambda j:-reviewed[j]):
  soc=str(codes[j]);con=mv.multiply(v[j]).tocsr();order=np.argsort(-con.data);shared=[]
  for k in order:
   task=tids[con.indices[k]];ms=[m for m in matches if str(m[0])==task]
   shared.append({'task_id':task,'task':ms[0][1],'contribution':float(con.data[k]),'quotes':[quote_map[m[2]] for m in ms]})
  dominant=shared[0]['task_id'] if shared else None
  loo=scores(accepted-{dominant}) if dominant else reviewed
  dmdc8=sorted({r[f'ONET{k}'] for r in refs for k in range(1,5) if r.get(f'ONET{k}','')[:7]==soc})
  cool8=sorted(set(cr.loc[cr['O*NET-SOC Code'].str[:7]==soc,'O*NET-SOC Code']))
  bi=int(np.argmax(anchor_scores[:,j]));anchor=anchors[bi]
  records.append({'doc_id':doc,'branch':d['branch'],'military_code':d['military_code'],'military_title':d['title'],'soc':soc,'soc_title':names.get(soc,soc),'dmdc_soc8':dmdc8,'cool_soc8':cool8,'manual_soc6':d['nlx_crosswalk']['6']['manual_references'],'anchor':anchor,'selected_routes':[{'anchor':ac,'provider':selections[ac]['provider'],'criterion':selections[ac]['criterion'],'posting_value':selections[ac]['posting_value'],'onet_value':selections[ac]['onet_value'],'benchmark_disagreement':selections[ac]['benchmark_disagreement'],'rank':selections[ac]['selected_top20'].index(soc)+1} for ac in anchors if ac in selections and soc in selections[ac]['selected_top20']],'onet_anchor_relatedness':onet.get((anchor,soc)),'anchor_cosine':float(best[j]),'anchor_rank':int(np.sum(anchor_scores[bi]>best[j]+1e-12)+1),'prior_candidate':any(r['doc_id']==doc and r['soc']==soc for r in prior_candidates),'source_group_ablation':[{'source_quote':q,'removed_task_ids':sorted(ts),'cosine':float(ss[j]),'rank':rank(ss,j)} for q,ts,ss in source_ablations],'duty_family_ablation':[{'family':family,'source_quotes':evidence,'removed_task_ids':sorted(ts),'cosine':float(ss[j]),'rank':rank(ss,j)} for family,evidence,ts,ss in family_ablations],'duty_family_ablation_policy':'Overlapping broad source-keyword families, explicit patterns in code; over-removes every feature attached to any matching quote. Diagnostic only, not independent occupational adjudication.','source_group_ablation_note':'Statement-linked feature removal is not independent duty-family removal; shared policy/security duty areas can remain correlated. No robustness certification.','raw_cosine':float(raw[j]),'raw_rank':rank(raw,j),'reviewed_cosine':float(reviewed[j]),'reviewed_rank':rank(reviewed,j),'shared_task_count':len(shared),'largest_task_share':float(con.data.max()/con.sum()) if shared else None,'leave_largest_out_cosine':float(loo[j]),'leave_largest_out_rank':rank(loo,j),'reviewed_task_count':len(accepted),'raw_task_count':len(alltasks),'shared_tasks':shared,'source_url':d['source_url'],'status':'Documented correspondence' if dmdc8 or cool8 else 'Exploratory connection','review_note':'','requirements':'Individual qualifications and employer requirements have not been verified.'})
# Preserve assignments that disappeared after clean native re-inference.
for old in prior_decisions:
 if not any(d['doc_id']==old['doc_id'] and d['task_id']==old['task_id'] for d in decisions):
  decisions.append({**old,'decision':'absent after clean native re-inference','reason':EXCLUSION_REASONS.get(old['task_id'],'')+' Assignment no longer emitted by frozen native JAAT for the cleaned input; old quotations are preserved solely as pre-repair evidence.','quotes_vintage':'pre-repair; may contain footer artifacts'})
(OUT/'candidates.json').write_text(json.dumps(records,indent=2));(OUT/'task_review.json').write_text(json.dumps(decisions,indent=2))
(OUT/'manifest.json').write_text(json.dumps({'input_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':list(ACCEPT),'representation':'sqrt(q * rca_weight), L2 normalized; shared NLx reference weights for binary military and pooled SOC6 NLx profiles','policy':'Pilot selected for evidence review, not representative validation. DMDC and O*NET-hosted COOL are documented separately; not independent votes. Raw ranks retained. Reviewed sensitivity uses an inherited provisional task allowlist with four specifically unsupported mappings removed; retained assignments are not independently adjudicated. Quotes can contain unsupported details. Source-statement group ablations remove all features linked to each quote; this does not establish independent duty-family robustness. Largest-task removal is re-normalized and ranked against all eligible NLx destinations. SOC6 aggregates can conceal specialty mismatch; retain source SOC8 references. No universal cosine cutoff.'},indent=2))
for doc in ACCEPT:
 print('\n'+doc)
 for r in [r for r in records if r['doc_id']==doc][:12]:print(r['soc'],r['soc_title'][:34],round(r['reviewed_cosine'],3),r['shared_task_count'],r['leave_largest_out_rank'],r['status'],r['cool_soc8'])
