import hashlib,json,sys,tempfile,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P))
from repair_coding import cache_fingerprint,load_cache
class RepairCacheTests(unittest.TestCase):
 def setUp(self):
  self.doc={'doc_id':'navy_example','body':'Clean duty text.','body_sha256':hashlib.sha256(b'Clean duty text.').hexdigest()}
  self.config={'versions':{'JAAT':'1.1.3'},'embedding_revision':'embedding-rev','classifier_revision':'classifier-rev','task_threshold':.87}
  self.fp=cache_fingerprint(self.config,'adapter-hash','inventory-hash')
 def load(self,record,doc=None,fp=None):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'recoded.jsonl';p.write_text(json.dumps(record)+'\n')
   return load_cache(p,[doc or self.doc],fp or self.fp)
 def entry(self):return {'doc_id':self.doc['doc_id'],'body_sha256':self.doc['body_sha256'],'inference_fingerprint':self.fp,'task':{'matches':[]}}
 def test_matching_body_and_configuration_reused(self):self.assertEqual(self.load(self.entry())[self.doc['doc_id']],self.entry())
 def test_changed_body_rejected_for_same_document_id(self):
  doc={**self.doc,'body':'Different duty.','body_sha256':hashlib.sha256(b'Different duty.').hexdigest()}
  with self.assertRaisesRegex(ValueError,'body hash'):self.load(self.entry(),doc)
 def test_changed_model_configuration_rejected(self):
  fp=cache_fingerprint({**self.config,'task_threshold':.9},'adapter-hash','inventory-hash')
  with self.assertRaisesRegex(ValueError,'fingerprint'):self.load(self.entry(),fp=fp)
 def test_missing_legacy_fingerprint_rejected(self):
  record=self.entry();del record['inference_fingerprint']
  with self.assertRaisesRegex(ValueError,'fingerprint'):self.load(record)
 def test_incorrect_current_body_metadata_rejected(self):
  with self.assertRaisesRegex(ValueError,'Current body hash'):self.load(self.entry(),{**self.doc,'body':'Changed without updating hash'})
 def test_fingerprint_covers_adapter_inventory_models_and_versions(self):
  for config,a,i in [({**self.config,'embedding_revision':'new'},'adapter-hash','inventory-hash'),({**self.config,'classifier_revision':'new'},'adapter-hash','inventory-hash'),({**self.config,'versions':{'JAAT':'other'}},'adapter-hash','inventory-hash'),(self.config,'new','inventory-hash'),(self.config,'adapter-hash','new')]:
   self.assertNotEqual(self.fp,cache_fingerprint(config,a,i))
if __name__=='__main__':unittest.main()
