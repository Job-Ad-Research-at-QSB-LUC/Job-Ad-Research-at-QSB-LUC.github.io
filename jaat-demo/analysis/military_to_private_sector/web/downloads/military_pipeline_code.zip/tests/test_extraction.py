import unittest,json,sys,re,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import extract_descriptions as e

class SourceRegressionTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.docs=[json.loads(l) for l in (ROOT/'inputs/descriptions.jsonl').read_text().splitlines()]
 def test_army_adjacent_occupations_are_separate(self):
  for code,wrong in [('15F','1110-15G.'),('25D','MOS 25H—'),('42R','MOS 42S--'),('150A','8-150. MOS 150U'),('170A','8-170. MOS 170B'),('920B','8-921.')]:
   entries=[d for d in self.docs if d['branch']=='army' and d['military_code']==code]
   self.assertTrue(entries,code)
   for d in entries:self.assertNotIn(wrong,d['raw_text'])
  for code in ['15G','25H','42S','150U','170B','921A','922A','923A','94A','94D']:
   self.assertTrue(any(d['military_code']==code for d in self.docs),code)
 def test_navy_long_titles_and_ratings(self):
  navy=[d for d in self.docs if d['branch']=='navy' and d.get('record_type')!='common_standard']
  self.assertEqual(len(navy),252)
  for code in ['002828','002832','001497','001687']:self.assertTrue(any(d['military_code']==code for d in navy))
  self.assertTrue(all(d['rating'] for d in navy))
  for d in navy:self.assertNotRegex(d['raw_text'],r'\f\s*CHAPTER\s+\d+')
 def test_source_identity_and_spans(self):
  source={n.stem:n.read_text() for n in (ROOT/'sources').glob('*.txt')}
  for d in self.docs:
   self.assertEqual(source[Path(d['source_file']).stem][d['source_start']:d['source_end']],d['raw_text'],d['doc_id'])
   self.assertEqual(hashlib.sha256(d['body'].encode()).hexdigest(),d['body_sha256'])
   if d['common_text']:self.assertTrue(d['body'].startswith(d['common_text']))
   self.assertNotRegex(d['body'],r'\b\d{2}-\d{4}\b')
 def test_navy_footer_and_source_rows(self):
  source=(ROOT/'sources/navy_jul26.txt').read_text()
  for d in self.docs:
   for t in d.get('task_inventory',[]):
    self.assertNotRegex(t['text'],r' [A-Z]{2,5}-\d+$')
    self.assertEqual(t['text'],' '.join(x['text'].strip() for x in t['source_spans']))
    for span in t['source_spans']:self.assertEqual(source[span['start']:span['end']],span['text'])
  d=next(d for d in self.docs if d['doc_id']=='navy_002779_0212')
  self.assertIn('Implement remediation plans for identified vulnerabilities',[t['text'] for t in d['task_inventory']])
 def test_general_standards_remain_paygrade_scoped(self):
  common=[d for d in self.docs if d.get('record_type')=='common_standard']
  self.assertEqual({d['paygrade'] for d in common},{f'E{i}' for i in range(1,10)})
  self.assertTrue(all(d['standard_inventory'] for d in common))
 def test_grouped_army_codes_are_not_single_mos(self):
  groups=[d for d in self.docs if d.get('grouped_specification')]
  self.assertEqual(len(groups),5)
  self.assertTrue(all(len(d['member_codes'])>1 for d in groups))

if __name__=='__main__':unittest.main()
