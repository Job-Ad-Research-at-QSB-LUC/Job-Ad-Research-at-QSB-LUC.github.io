import unittest,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from select_anchor_models import select
class SelectionTests(unittest.TestCase):
 def test_sst_primary_despite_emsi_disagreement(self):
  r=select({'Posting-task':{'SST share':.3,'DOL rank':.1},'O*NET':{'SST share':.2,'DOL rank':.5}});self.assertEqual(r['provider'],'Posting-Tasks');self.assertEqual(r['criterion'],'SST share')
 def test_emsi_fallback(self):
  self.assertEqual(select({'Posting-task':{'DOL rank':.1},'O*NET':{'DOL rank':.2}})['provider'],'O*NET published')
 def test_missing_is_not_zero(self):
  self.assertEqual(select({'Posting-task':{'SST share':.3},'O*NET':{}})['provider'],'unavailable')
 def test_tie_no_claim_of_best(self):
  self.assertEqual(select({'Posting-task':{'SST share':.3},'O*NET':{'SST share':.3}})['provider'],'tie')
