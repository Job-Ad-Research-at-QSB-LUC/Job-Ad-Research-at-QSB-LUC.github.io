import unittest,json,zipfile
from pathlib import Path
P=Path(__file__).resolve().parents[1]
class RepairOutputTests(unittest.TestCase):
 def test_all_pre_repair_candidates_remain(self):
  with zipfile.ZipFile(P/'repair_20260929/before.zip') as z:old=json.loads(z.read('outputs/pathway_review/candidates.json'))
  new=json.loads((P/'outputs/pathway_review/reviewed_pathways.json').read_text())
  self.assertLessEqual({(d['doc_id'],d['soc']) for d in old},{(d['doc_id'],d['soc']) for d in new})
  self.assertFalse(any(d['status']=='Supported extension' for d in new))
 def test_specific_mapping_exclusions(self):
  rows=json.loads((P/'outputs/pathway_review/task_review.json').read_text())
  for t in ['21298','21774','14648','3483']:
   d=next(d for d in rows if d['doc_id']=='navy_002779_0212' and d['task_id']==t)
   self.assertNotEqual(d['decision'],'retain for sensitivity');self.assertTrue(d['reason']);self.assertTrue(d['quotes'])
 def test_refreshed_body_and_source_provenance(self):
  docs={d['doc_id']:d for d in map(json.loads,(P/'inputs/descriptions.jsonl').read_text().splitlines())}
  for c in map(json.loads,(P/'outputs/coded_documents.jsonl').read_text().splitlines()):
   d=docs[c['doc_id']];self.assertEqual(c['body_sha256'],d['body_sha256'])
   for s in c['task']['stage1_decisions']:self.assertEqual(d['body'][s['start_char']:s['end_char']],s['source_quote'])
if __name__=='__main__':unittest.main()
