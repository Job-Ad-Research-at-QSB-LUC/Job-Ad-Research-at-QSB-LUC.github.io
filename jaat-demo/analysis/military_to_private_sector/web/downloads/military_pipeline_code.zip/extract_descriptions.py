"""Official manual text → versioned military descriptions; no learned coding here."""
from pathlib import Path
import re,json,hashlib
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'sources';OUT=ROOT/'inputs';OUT.mkdir(exist_ok=True)
def clean(text):
    lines=[]
    for l in text.splitlines():
        t=l.strip()
        if re.fullmatch(r'(?:\d+-\d+\s+)?Enclosure \(1\)|(?:\d+\s+)?NAVMC 1200\.1L|[A-Z]{2,5}-\d+|\d+|\d+-\d+',t):continue
        lines.append(t)
    return re.sub(r'\s+',' ','\n'.join(lines)).strip()
def record(branch,code,title,raw,body,common,source,start,end,seq,**extra):
    meta=json.loads((SRC/(source+'.json')).read_text());full=(common+'\n\n'+body).strip()
    return dict(doc_id=f'{branch}_{code}_{seq:04d}',branch=branch,military_code=code,title=title,source_file=source+'.pdf',source_url=meta['url'],source_sha256=meta['sha256'],source_start=start,source_end=end,raw_text=raw,common_text=common,occupation_text=body,body=full,body_sha256=hashlib.sha256(full.encode()).hexdigest(),**extra)
def army(source,kind):
    text=(SRC/(source+'.txt')).read_text()
    pat=re.compile(r'(?m)^(?:[\f \t]*(?:1110|10|8)[–—-][0-9A-Z]+\.\s+|[ \t]*\f[ \t]*MOS\s+(?=[0-9]{2,3}[A-Z]\s*[–—-]))[^\n]+')
    matches=list(pat.finditer(text));rows=[]
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(text);raw=text[m.start():end]
        head=clean(re.split(r'\n\s*a\.',raw,maxsplit=1)[0])
        # Some aviation specifications jointly describe several MOSs. Preserve
        # the group as a group, rather than assigning all text to its first MOS.
        pairs=list(re.finditer(r'\b([0-9]{2,3}[A-Z])\s*(?:--|—|–|-)\s*',head))
        codes=list(dict.fromkeys(p[1] for p in pairs))
        if not codes:
            codes=[re.search(r'(?:10|8)[–—-]([0-9]{2,3}[A-Z])',head)[1]]
            title=re.sub(r'^(?:1110|10|8)[–—-][0-9A-Z]+\.\s*','',head)
        elif len(codes)==1:
            title=head[pairs[0].end():]
        else:title=re.sub(r'^(?:1110|10|8)[–—-][0-9A-Z]+\.\s*','',head)
        title=re.split(r'\s+CMF\s|\s*\(Eff',title)[0].rstrip(' ,')
        effective=re.findall(r'(?:Effective|Eff)[^0-9]{0,5}(20\d{4})',head,re.I)
        rows.append(record('army','+'.join(codes),title,raw,clean(raw),'',source,m.start(),end,i,member_codes=codes,grouped_specification=len(codes)>1,personnel_category=kind,effective_month=effective[0] if effective else '',future_effective=bool(effective and effective[0]>'202609')))
    return rows

def marines():
    source='marines_fy26';text=(SRC/(source+'.txt')).read_text();fields=list(re.finditer(r'(?m)^\s*\d{4}\.\s+OCCUPATIONAL FIELD (\d{2})[^\n]*',text));rows=[]
    for fidx,f in enumerate(fields):
        fend=fields[fidx+1].start() if fidx+1<len(fields) else len(text);block=text[f.start():fend];mos=list(re.finditer(r'(?m)^\s*\d+\.\s+MOS (\d{4}),\s*([^\n]+)',block))
        if not mos:continue
        common=clean(block[f.end()-f.start():mos[0].start()]);common=re.sub(r'^1\.\s*Introduction\.\s*','',common)
        for i,m in enumerate(mos):
            end=mos[i+1].start() if i+1<len(mos) else len(block);raw=block[m.start():end]
            # Reference sections preserved in raw_text but withheld from coding.
            cut=re.search(r'(?mi)^\s*[a-z]\.\s+(?:Related (?:Standard|SOC|Military|Department)|SOC Classification)',raw)
            body=raw[:cut.start()] if cut else raw
            rows.append(record('marines',m[1],clean(m[2]),raw,clean(body),common,source,f.start()+m.start(),f.start()+end,len(rows),occupational_field=f[1],personnel_category='officer' if f.start()<text.find('3108.       OCCUPATIONAL FIELD') else 'enlisted',effective_month='202510',future_effective=False,reference_text=raw[cut.start():] if cut else ''))
    return rows

def navy():
    source='navy_jul26';text=(SRC/(source+'.txt')).read_text();matches=list(re.finditer(r'(?m)^\s*Job Title\s+Job Code\s*\n([^\n]+)',text));rows=[]
    scopes=list(re.finditer(r'(?m)^\s*SCOPE OF RATING\s*$',text))
    for i,m in enumerate(matches):
        end=matches[i+1].start() if i+1<len(matches) else len(text);raw=text[m.start():end];h=re.match(r'\s*(.*?)\s+(\d{6})\s*$',m[1])
        if not h:continue
        title,code=h.groups();desc=re.search(r'Job Description\s*\n(.*?)(?=\n\s*DoD Relationship|\n\s*Skills\s+Abilities|\n\s*Paygrade)',raw,re.S)
        if not desc:continue
        # The last job of a rating must stop before the next rating's front matter.
        boundary=re.search(r'\f\s*CHAPTER\s+\d+|\n\s*NAVY ENLISTED OCCUPATIONAL STANDARD FOR',raw)
        own=raw[:boundary.start()] if boundary else raw
        scope=[s for s in scopes if s.start()<m.start()];common='';rating=''
        if scope:
            st=scope[-1].end();e=re.search(r'This Occupational Standard|GENERAL INFORMATION',text[st:m.start()]);common=clean(text[st:st+e.start()] if e else text[st:m.start()])
            rate=re.search(r'(?mi)^\s*Enlisted\s+([A-Z]{2,5})\b',raw);rating=rate[1] if rate else ''
        # Table task rows preserve paygrade separately; source wording is unchanged.
        tasks=[];current=None
        for lm in re.finditer(r"[^\n]*(?:\n|$)",own):
            line=lm[0].rstrip("\n")
            # Standalone page identifiers are layout metadata, never continuations.
            if re.fullmatch(r"[A-Z]{2,5}-\d+",line.strip()):continue
            r=re.match(r'^\s*(E[1-9])\s+(CORE|NON-CORE|NONCORE)\s+(.*)',line)
            if r:
                if current:tasks.append(current)
                current={'paygrade':r[1],'type':r[2],'text':r[3].strip(),'source_spans':[{'start':m.start()+lm.start()+r.start(3),'end':m.start()+lm.start()+r.end(3),'text':r[3]}]}
            elif current and line.strip() and re.match(r'^\s{15,}\S',line) and not re.search(r'Paygrade|Task Type|Task Statements|CONT.|^[A-Z -]+$',line.strip()):
                current['text']+=' '+line.strip()
                current['source_spans'].append({'start':m.start()+lm.start()+len(line)-len(line.lstrip()),'end':m.start()+lm.start()+len(line.rstrip()),'text':line.strip()})
            else:
                if current:tasks.append(current);current=None
        if current:tasks.append(current)
        body=clean(desc[1])+'\n\n'+'\n'.join(t['text'].rstrip('.;')+'.' for t in tasks)
        rows.append(record('navy',code,title,own,body,common,source,m.start(),m.start()+len(own),len(rows),rating=rating,personnel_category='enlisted',manual_version='Change 107, July 2026',effective_month='' ,future_effective=False,task_inventory=tasks,reference_withheld='DoD/O*NET relationship and skills/abilities columns retained only in raw_text'))
    return rows

def naval_standards():
    source='navy_jul26';text=(SRC/(source+'.txt')).read_text()
    end=re.search(r'\f\s*CHAPTER\s+1\b',text).start()
    pages=text[:end].split('\f');group={};offset=0
    for page in pages:
        grade=re.search(r'(?m)^\s*(E[1-9])\s*$',page)
        if grade and 'Naval Standards by Functional Area' in page:
            rows=[];current=None
            for line in page.splitlines():
                m=re.match(r'^\s*([A-Z]\d{3})\s+(.+)',line)
                if m:
                    if current:rows.append(current)
                    current={'standard_code':m[1],'text':m[2].strip()}
                elif current and re.match(r'^ {5,}\S',line) and not re.search(r'NAVSTDS-|Naval Standards|CONT|^[A-Z &/-]+$',line.strip()):current['text']+=' '+line.strip()
                else:
                    if current:rows.append(current);current=None
            if current:rows.append(current)
            g=group.setdefault(grade[1],{'rows':[],'start':offset,'end':offset+len(page)})
            g['rows'].extend(rows);g['end']=offset+len(page)
        offset+=len(page)+1
    out=[]
    for grade,g in sorted(group.items()):
        body='\n'.join(r['text'].rstrip('.;')+'.' for r in g['rows'])
        out.append(record('navy','NAVSTD-'+grade,'General Naval Standards '+grade,text[g['start']:g['end']],body,'',source,g['start'],g['end'],len(out),record_type='common_standard',paygrade=grade,standard_inventory=g['rows'],personnel_category='enlisted',manual_version='Change 107, July 2026; NAVSTDs January 2023',effective_month='',future_effective=False))
    assert len(out)==9, 'Every NAVSTD paygrade must be represented'
    return out

def main():
    rows=army('army_enlisted','enlisted')+army('army_warrant','warrant')+marines()+navy()+naval_standards()
    with (OUT/'descriptions.jsonl').open('w') as f:
        for r in rows:f.write(json.dumps(r,ensure_ascii=False)+'\n')
    from collections import Counter
    counts=Counter(r['branch'] for r in rows);print(counts)
    (OUT/'extraction_manifest.json').write_text(json.dumps({'counts':counts,'documents':len(rows),'policy':'Common occupation-field/rating text retained. Military code revisions remain separate. Civilian reference sections withheld from JAAT input and retained in raw text. Navy table rows converted to sentences without paraphrase; paygrades retained.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
if __name__=='__main__':main()
