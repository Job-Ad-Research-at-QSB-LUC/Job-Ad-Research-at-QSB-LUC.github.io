"""Audit before/after extraction, model outputs, scoring and release artifacts."""
from pathlib import Path
import json,zipfile,hashlib,re
import numpy as np
P=Path(__file__).resolve().parent;R=P/'repair_20260929'
def read(p):return {d['doc_id']:d for d in map(json.loads,p.read_text().splitlines())}
def main():
 with zipfile.ZipFile(R/'before.zip') as z:
  before={d['doc_id']:d for d in map(json.loads,z.read('inputs/descriptions.jsonl').decode().splitlines())}
  oldcodes={d['doc_id']:d for d in map(json.loads,z.read('outputs/coded_documents.jsonl').decode().splitlines())}
  oldcandidates=json.loads(z.read('outputs/pathway_review/candidates.json'))
 after=read(P/'inputs/descriptions.jsonl');coded=read(P/'outputs/coded_documents.jsonl')
 changes=[]
 for doc,d in after.items():
  assert coded[doc]['body_sha256']==d['body_sha256']
  for s in coded[doc]['task']['stage1_decisions']:assert d['body'][s['start_char']:s['end_char']]==s['source_quote']
  if d['body_sha256']!=before[doc]['body_sha256']:
   a={str(m[0]) for m in oldcodes[doc]['task']['matches']};b={str(m[0]) for m in coded[doc]['task']['matches']}
   changes.append({'doc_id':doc,'old_body_sha256':before[doc]['body_sha256'],'new_body_sha256':d['body_sha256'],'removed_task_ids':sorted(a-b),'added_task_ids':sorted(b-a),'old_matches':len(oldcodes[doc]['task']['matches']),'new_matches':len(coded[doc]['task']['matches'])})
 footer=lambda ds:sum(bool(re.search(r' '+re.escape(d.get('rating',''))+r'-\d+$',t['text'])) for d in ds.values() for t in d.get('task_inventory',[]))
 result={'body_changes':len(changes),'profiles_with_task_set_changes':sum(bool(d['removed_task_ids'] or d['added_task_ids']) for d in changes),'footer_tasks_before':footer(before),'footer_tasks_after':footer(after),'original_candidate_count':len(oldcandidates),'body_hash_and_all_classifier_quote_spans_verified':True,'changes':changes}
 (R/'comparison.json').write_text(json.dumps(result,indent=2))
 print({k:v for k,v in result.items() if k!='changes'})
if __name__=='__main__':main()
