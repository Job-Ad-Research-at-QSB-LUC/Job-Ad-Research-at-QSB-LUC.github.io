"""Descriptive per-anchor model selection, not held-out hybrid validation."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;ROOT=P.parents[1]
BASE=ROOT/'analysis/relatedness_refresh_20260922/web'
def readjs(p):
 s=p.read_text();return json.loads(s[s.index('(')+1:s.rindex(')')])
def select(metrics):
 for metric in ['SST share','DOL rank']:
  a=metrics.get('Posting-task',{}).get(metric);b=metrics.get('O*NET',{}).get(metric)
  if a is not None and b is not None:
   if abs(a-b)<1e-12:return {'provider':'tie','criterion':metric,'posting_value':a,'onet_value':b,'note':'Equal benchmark recovery; no unique provider selected.'}
   return {'provider':'Posting-Tasks' if a>b else 'O*NET published','criterion':metric,'posting_value':a,'onet_value':b,'note':'Larger observed point estimate; no occupation-specific significance claim.'}
 return {'provider':'unavailable','criterion':None,'posting_value':None,'onet_value':None,'note':'No comparable SST-share or EMSI result; no best provider claimed.'}
def main():
 p=BASE/'occupation_benchmarks.js';b=json.loads(p.read_text().split('=',1)[1].rstrip(';\n'));out={}
 for code,d in b['occupations'].items():
  path=BASE/'occupation_relatedness_data'/f'{code}.js'
  if not path.exists():continue
  x=readjs(path);m=d['metrics'];s=select(m)
  lists={'Posting-Tasks':x['lists']['task'][:20],'O*NET published':x['lists']['official'][:20]}
  signs=[(m['Posting-task'][k]-m['O*NET'][k]) for k in ['SST share','DOL rank'] if m['Posting-task'].get(k) is not None and m['O*NET'].get(k) is not None]
  out[code]={**s,'title':d['title'],'ranking_population':x.get('coverage',{}).get('ranking_population','Full dashboard SOC6 lists; benchmark-specific candidate populations differ'),'listed_destination_counts':{k:len(v) for k,v in lists.items()},'absolute_selection_margin':abs(s['posting_value']-s['onet_value']) if s['posting_value'] is not None and s['onet_value'] is not None else None,'selection_validation':'Descriptive in-sample point-estimate routing; no held-out adaptive-policy validation or significance threshold.','metrics':m,'benchmark_disagreement':any(v>0 for v in signs) and any(v<0 for v in signs),'lists':lists,'selected_top20':lists.get(s['provider'],[]),'ranking_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 dest=P/'outputs/pathway_review/anchor_model_selection.json';dest.write_text(json.dumps({'policy':'Primary SST transition share at top20; fallback EMSI top20 destination recovery. Exact ties and missing comparisons select no unique provider. Published O*NET lists can be shorter than 20. Model choice uses observed benchmark performance; not independently evaluated adaptive performance. Candidate lists are the existing full dashboard SOC6 lists, not the benchmark-specific restricted lists. Source disagreements are retained.','benchmark_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'anchors':out},indent=2))
 print('Anchor model choices',len(out))
if __name__=='__main__':main()
