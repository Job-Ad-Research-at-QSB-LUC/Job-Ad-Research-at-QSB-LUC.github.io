"""Military binary task profiles → pooled NLx SOC profiles; references held out.
Uses local NLx aggregates. Do not include those inputs in the public-source archive.
"""
from pathlib import Path
import sys,json,re,hashlib,math
import numpy as np,pandas as pd
from scipy import sparse
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parents[1]
sys.path.insert(0,str(PROJECT/'analysis/occupation_relatedness'))
from metrics import representation
from public_nlx_evidence import shared as public_shared
OUT=ROOT/'outputs/nlx_crosswalk';OUT.mkdir(exist_ok=True)
WEB=ROOT/'web';D=WEB/'data'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def metrics(scores,codes,refs):
    ix={c:i for i,c in enumerate(codes)};positive=np.round(scores,12);valid=positive>0
    rs=[positive[ix[c]] for c in refs if c in ix and valid[ix[c]]]
    result={'reference_count':len(refs),'reference_in_universe':len(set(refs)&set(codes)),'positive_destinations':int(valid.sum()),'best_reference_rank':None}
    if rs:result['best_reference_rank']=int(np.sum(positive>max(rs))+1)
    for k in [1,5,10,20]:
        probs=[np.clip((k-np.sum(positive>s))/np.sum(positive==s),0,1) for s in rs]
        result[f'recall{k}']=float(sum(probs)/len(refs)) if refs else None
        # Exact expected any-reference hit under uniform ordering of tied scores.
        kk=min(k,int(valid.sum()));hit=0.
        if kk and rs:
            boundary=np.sort(positive[valid])[-kk]
            if any(s>boundary for s in rs):hit=1.
            else:
                good=sum(s==boundary for s in rs);n=int(np.sum(positive==boundary));take=kk-int(np.sum(positive>boundary))
                if good:hit=1-(math.comb(n-good,take)/math.comb(n,take) if n-good>=take else 0)
        result[f'hit{k}']=hit if refs else None
    return result

def main():
    old=PROJECT/'analysis/occupation_relatedness/results'
    paths={'nlx_marginals':PROJECT/'data/release/occupation_task_marginals.csv.gz','nlx_totals':PROJECT/'data/release/occupation_totals.csv','exclusion_mask':PROJECT/'analysis/relatedness_refresh_20260922/applied/exclusion_mask.csv','rca_weights':PROJECT/'analysis/relatedness_refresh_20260922/results/task_rca_feature_weights.csv','columns':old/'task_matrix_columns.csv','military_inputs':ROOT/'inputs/descriptions.jsonl','military_coding':ROOT/'outputs/coded_documents.jsonl'}
    inc=pd.read_csv(paths['nlx_marginals']);tot=pd.read_csv(paths['nlx_totals']);mask=pd.read_csv(paths['exclusion_mask'])
    tids=pd.read_csv(paths['columns']).task_id.to_list();ti={str(t):i for i,t in enumerate(tids)}
    weights=pd.read_csv(paths['rca_weights']);assert list(weights.unit_id)==tids;rca_weight=weights.rca_weight.to_numpy();assert np.isfinite(rca_weight).all() and (rca_weight >= 0).all()
    blocked=pd.MultiIndex.from_frame(mask[['occ8','task_id']]);inc=inc[~pd.MultiIndex.from_frame(inc[['occupational_code','task_id']]).isin(blocked)]
    inc=inc[inc.n_jobs_with_task.ge(5)&inc.task_id.astype(str).isin(ti)]
    paths.update(dmdc_crosswalk=ROOT/'reference/military_crosswalk.zip',representation_code=PROJECT/'analysis/occupation_relatedness/metrics.py',occupation_labels=old/'occupation_coverage.csv')
    docs=[json.loads(l) for l in paths['military_inputs'].read_text().splitlines()];coded={x['doc_id']:x for x in map(json.loads,paths['military_coding'].read_text().splitlines())}
    assert all(coded[d['doc_id']]['body_sha256']==d['body_sha256'] for d in docs),'Military coding body hash mismatch'
    # Use corrected metadata and held-out crosswalk rows already audited by report builder.
    details=[json.loads((D/(d['doc_id']+'.json')).read_text()) for d in docs]
    reference_sha=hashlib.sha256(json.dumps([(d['doc_id'],d['reference_crosswalk']) for d in details],sort_keys=True,separators=(',',':')).encode()).hexdigest()
    task_text={str(m[0]):m[1] for c in coded.values() for m in c['task']['matches']}
    rows=[];cols=[];unmapped={}
    for i,d in enumerate(docs):
        tasks={str(m[0]) for m in coded[d['doc_id']]['task']['matches']};unmapped[d['doc_id']]=sorted(tasks-set(ti))
        for t in sorted(tasks&set(ti)):rows.append(i);cols.append(ti[t])
    military=sparse.csr_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(docs),len(tids)));_,mv=representation(military,rca_weight)
    coverage=pd.read_csv(old/'occupation_coverage.csv');titles8=coverage.set_index('occupational_code').occupation_title.to_dict()
    # Six-digit parent labels use .00 when available, otherwise retain constituent titles.
    title6={c:' / '.join(sorted(set(g.occupation_title))) for c,g in coverage.groupby(coverage.occupational_code.str[:7])}
    for c,t in titles8.items():
        if c.endswith('.00'):title6[c[:7]]=t
    allrows=[];bench=[];payload={d['doc_id']:{} for d in docs};matrices={}
    for level in [6,8]:
        q=inc.copy();q['soc']=q.occupational_code.str[:7] if level==6 else q.occupational_code
        totals=tot.groupby(tot.occupational_code.str[:7] if level==6 else tot.occupational_code).n_jobs.sum()
        codes=sorted(c for c in totals[totals.ge(200)].index if not c.startswith('55-'));ci={c:i for i,c in enumerate(codes)};q=q[q.soc.isin(ci)]
        x=sparse.csr_matrix((q.weighted_jobs_with_task,(q.soc.map(ci),q.task_id.astype(str).map(ti))),shape=(len(codes),len(tids)))
        keep=np.asarray(x.sum(1)).ravel()>0;x=x[keep];codes=np.array(codes)[keep];_,v=representation(x,rca_weight);scores=np.clip((mv@v.T).toarray(),0,1);matrices[str(level)]=(codes,scores)
        names=title6 if level==6 else titles8
        for i,(d,detail) in enumerate(zip(docs,details)):
            refs=detail['reference_crosswalk']['rows'];active=[r for r in refs if r['STATUS']=='A'];prefix='SOC' if level==6 else 'ONET'
            official=sorted({r[f'{prefix}{k}'] for r in active for k in range(1,5) if re.fullmatch(r'\d{2}-\d{4}'+(r'\.\d{2}' if level==8 else ''),r.get(f'{prefix}{k}',''))})
            manual=sorted(set(re.findall(r'\b\d{2}-\d{4}(?:\.\d{2})?\b',d.get('reference_text','') if d['branch']=='marines' else d['raw_text'] if d['branch']=='navy' else '')))
            manual=sorted({c[:7] if level==6 else c for c in manual if level==6 or len(c)==10})
            order=np.flatnonzero(scores[i]>0);order=order[np.argsort(-scores[i,order],kind='stable')][:20];neighbors=[]
            for rank,j in enumerate(order,1):
                row=dict(doc_id=d['doc_id'],branch=d['branch'],military_code=d['military_code'],military_title=detail['title'],soc_level=level,rank=rank,soc=str(codes[j]),soc_title=names.get(codes[j],codes[j]),cosine=float(scores[i,j]),dmdc_reference_match=codes[j] in official,manual_reference_match=codes[j] in manual)
                allrows.append(row)
                contribution=mv.getrow(i).multiply(v.getrow(j)).tocsr();assert abs(float(contribution.sum())-scores[i,j])<1e-10
                strongest=np.argsort(-contribution.data)[:5]
                shared=[{'task_id':str(tids[contribution.indices[k]]),'task':task_text.get(str(tids[contribution.indices[k]]),''),'cosine_contribution':float(contribution.data[k])} for k in strongest]
                permitted=public_shared(shared,str(codes[j]))
                neighbors.append(dict(row,shared_tasks=permitted,withheld_shared_task_count=len(shared)-len(permitted),public_evidence_note='Shown NLx task contributions are partial, public-permitted explanations; full score/rank unchanged. Government coding unrestricted.'))
            for reference,truth in [('dmdc_2024_active',official),('manual_soc',manual)]:
                bench.append(dict(doc_id=d['doc_id'],branch=d['branch'],military_code=d['military_code'],soc_level=level,reference=reference,record_type=d.get('record_type','occupation_entry'),nonfuture_individual=not d.get('future_effective',False) and not d.get('grouped_specification',False) and d.get('record_type')!='common_standard',**metrics(scores[i],codes,truth)))
            payload[d['doc_id']][str(level)]={'top20':neighbors,'dmdc_references':official,'manual_references':manual,'dmdc_metrics':metrics(scores[i],codes,official),'manual_metrics':metrics(scores[i],codes,manual),'unmapped_task_ids':unmapped[d['doc_id']]}
        np.savez_compressed(OUT/f'all_scores_soc{level}.npz',doc_ids=np.array([d['doc_id'] for d in docs]),codes=codes,scores=scores)
    pd.DataFrame(allrows).to_csv(OUT/'top20_soc_destinations.csv',index=False)
    b=pd.DataFrame(bench);b.to_csv(OUT/'reference_comparison_by_entry.csv',index=False)
    summary=[]
    for (level,branch,ref),g in b.groupby(['soc_level','branch','reference']):
        g=g[g.nonfuture_individual & g.reference_count.gt(0)]
        summary.append(dict(soc_level=level,branch=branch,reference=ref,entries_with_reference=len(g),entries_with_retrievable_reference=int(g.reference_in_universe.gt(0).sum()),entries_with_task_destinations=int(g.positive_destinations.gt(0).sum()),hit20_retrievable=float(g.loc[g.reference_in_universe.gt(0),'hit20'].mean()) if g.reference_in_universe.gt(0).any() else None,**{c:float(g[c].mean()) if len(g) else None for c in ['hit1','hit5','hit10','hit20','recall20']}))
    pd.DataFrame(summary).to_csv(OUT/'reference_comparison_summary.csv',index=False)
    reviews=json.loads((OUT/'task_coding_review.json').read_text()) if (OUT/'task_coding_review.json').exists() else []
    note='NLx employer-demand profiles; private-only ownership unverified. Six-digit profiles pool specialty weighted task incidences after the existing review exclusion mask and five-job task-support floor; destination SOCs require 200 postings and nonzero tasks. Military profiles use binary accepted task presence and the same NLx reference RCA weights as civilian profiles: reciprocal positive task shares (zero weight for reference-absent tasks) of pooled retained support-five NLx weighted incidences across 1,016 reference specialties (912 eligible comparison candidates), sqrt(q * rca_weight), then L2 normalization and cosine. No military crosswalk codes enter the task ranking. All positive top-20 results retained; zero-similarity destinations are not recommendations. Shared field/rating duties are included; general Naval Standards remain separate by paygrade. Summary compares non-future individual source entries (versions can repeat) with nonempty reference sets; grouped, future and general-standard entries remain in all outputs. Hit@k is the fraction with at least one reference SOC recovered; ties are averaged exactly. References outside NLx remain in denominators. DMDC reference status is from July 2024, not current 2026 status.'
    for d in details:
        d['nlx_task_review']=[r for r in reviews if r['doc_id']==d['doc_id']];d['nlx_crosswalk']=payload[d['doc_id']];d['nlx_method']=note;(D/(d['doc_id']+'.json')).write_text(json.dumps(d,ensure_ascii=False))
    (OUT/'manifest.json').write_text(json.dumps({'method':note,'input_hashes':{k:sha(p) for k,p in paths.items()},'task_review_sha256':sha(OUT/'task_coding_review.json') if reviews else None,'reference_mapping_sha256':reference_sha,'script_sha256':sha(Path(__file__)),'n_destinations':{k:len(v[0]) for k,v in matrices.items()},'n_records':len(docs)},indent=2))
    (D/'nlx_summary.json').write_text(json.dumps({'method':note,'summary':summary},indent=2,allow_nan=False));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
