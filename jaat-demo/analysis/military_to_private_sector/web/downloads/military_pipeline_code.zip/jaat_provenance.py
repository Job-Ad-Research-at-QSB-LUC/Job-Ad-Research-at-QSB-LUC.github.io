"""Unchanged provenance adapters from the supplied CalHR JAAT notebook."""
import re,json
import numpy as np
from collections import defaultdict,deque
CLEAN_RE=re.compile(r'(;|\s\+\s|\s\*\s|\s\-\s|\s•\s|\s·\s|--|\*\*)')

def _replace_mapped(text, spans, pattern, replacement):
    pieces=[];mapped=[];pos=0
    for match in pattern.finditer(text):
        a,b=match.span();pieces.append(text[pos:a]);mapped.extend(spans[pos:a]);pieces.append(replacement)
        mapped.extend([(spans[a][0],spans[b-1][1])]*len(replacement));pos=b
    pieces.append(text[pos:]);mapped.extend(spans[pos:]);return ''.join(pieces),mapped

def sentence_records(body, tokenizer):
    stripped=body.strip();lead=len(body)-len(body.lstrip())
    text=stripped;spans=[(lead+i,lead+i+1) for i in range(len(text))]
    text,spans=_replace_mapped(text,spans,re.compile('\n'),'. ')
    text,spans=_replace_mapped(text,spans,CLEAN_RE,'. ')
    text,spans=_replace_mapped(text,spans,re.compile(r'\.\.'),'.')
    # tokenizer is JAAT.base.sent_tokenize, which accepts original input.
    sentences=tokenizer(stripped);cursor=0;rows=[]
    for i,s in enumerate(sentences):
        a=text.find(s,cursor)
        if a<0:raise ValueError('JAAT preprocessing changed; cannot prove source provenance')
        b=a+len(s);cursor=b
        start,end=spans[a][0],spans[b-1][1]
        rows.append(dict(sentence_index=i,normalized_sentence=s,start_char=start,end_char=end,
                         source_quote=body[start:end],word_count=len(s.split())))
    return rows

def jsonable(x):
    if isinstance(x, (list,tuple,set)): return [jsonable(v) for v in x]
    if isinstance(x, dict): return {str(k):jsonable(v) for k,v in x.items()}
    if hasattr(x, 'item'): return x.item()
    return x

def tasks_with_confidence(tm,docs,classifier_batch=32):
    from JAAT.base import sent_tokenize
    groups=[sentence_records(d['body'],sent_tokenize) for d in docs]
    eligible=[[s for s in group if 4<s['word_count']<=48] for group in groups]
    observed=[];original=tm.pipe
    class RecordingPipe:
        def __call__(self,data,**kwargs):
            kwargs.setdefault('batch_size',classifier_batch);kwargs.setdefault('num_workers',0)
            for prediction in original(data,**kwargs):observed.append(prediction);yield prediction
    tm.pipe=RecordingPipe()
    try:
        # This is JAAT's complete, unmodified task matching algorithm.
        native=tm.get_tasks_batch([d['body'] for d in docs],return_original=True)
    finally:tm.pipe=original
    flattened=[s for group in eligible for s in group]
    if len(observed)!=len(flattened) or len(native)!=len(docs):raise ValueError('JAAT classifier/result alignment changed')
    lengths=[len(x) for x in tm.tokenizer([s['normalized_sentence'] for s in flattened],truncation=False)['input_ids']] if flattened else []
    if len(lengths)!=len(flattened):raise ValueError('Tokenizer cardinality mismatch')
    for s,p,length in zip(flattened,observed,lengths):
        if p['label'] not in ('LABEL_0','LABEL_1'):raise ValueError('Unexpected classifier label')
        s.update(label=p['label'],classifier_score=float(p['score']),token_count=length,classifier_truncated=length>64)
    result=[]
    for all_sentences,rows,matches in zip(groups,eligible,native):
        by_text=defaultdict(deque)
        for match in matches:
            if len(match)!=3:raise ValueError('Expected JAAT return_original=True triples')
            by_text[match[2]].append(match)
        statements=[]
        for row in rows:
            if row['label']!='LABEL_1':continue
            match=by_text[row['normalized_sentence']].popleft() if by_text[row['normalized_sentence']] else None
            statements.append(dict(row,matched=match is not None,accepted_onet_match=jsonable(match),match_threshold=float(tm.threshold)))
        if any(by_text.values()):raise ValueError('Native task match has no corresponding stage1 candidate')
        result.append({'matches':jsonable(matches),'statements':statements,'stage1_decisions':rows,
          'coverage':{'segmented':len(all_sentences),'eligible':len(rows),'excluded_sentence_indices':[s['sentence_index'] for s in all_sentences if not 4<s['word_count']<=48]},
          'method':'JAAT.TaskMatch.get_tasks_batch(return_original=True)'})
    return result