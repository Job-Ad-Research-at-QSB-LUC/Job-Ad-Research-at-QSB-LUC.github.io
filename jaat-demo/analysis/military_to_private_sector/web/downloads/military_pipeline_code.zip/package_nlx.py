"""Package derived military/NLx comparisons, without redistributing NLx inputs."""
from pathlib import Path
import shutil,zipfile,json,hashlib
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs/nlx_crosswalk';DEST=ROOT/'web/downloads'
for name in ['top20_soc_destinations.csv','reference_comparison_summary.csv','reference_comparison_by_entry.csv','task_coding_review.csv','manifest.json']:
 shutil.copyfile(OUT/name,DEST/('nlx_'+name))
with zipfile.ZipFile(DEST/'nlx_comparison_results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():
  if p.is_file():z.write(p,p.relative_to(ROOT))
with zipfile.ZipFile(DEST/'military_pipeline_code.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in ROOT.iterdir():
  if p.suffix in ['.py','.ipynb'] or p.name in ['README.md','requirements-lock.txt']:z.write(p,p.name)
 for p in (ROOT/'tests').glob('*.py'):z.write(p,p.relative_to(ROOT))
 for p in (ROOT/'web').iterdir():
  if p.is_file():z.write(p,p.relative_to(ROOT))
(DEST/'manifest.json').write_text(json.dumps({p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in DEST.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2))
