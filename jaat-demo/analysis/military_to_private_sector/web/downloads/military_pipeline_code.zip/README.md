# Official military descriptions and native JAAT coding

Separate from CalHR, USAJOBS, and NLx. This package implements official-source extraction, native JAAT task/title coding, complete classifier and quotation provenance, and a local audit dashboard. An optional NLx comparison now ranks civilian SOC destinations from military tasks. It uses the available pooled NLx employer-demand aggregates; private-employer-only status remains unverified. Industry categories alone cannot establish employer ownership.

## Sources and attribution

Official PDFs were retrieved September 29, 2026. Each source JSON retains its official URL and SHA-256; layout text is retained beside the PDF.

- Army G-1 enlisted MOS and warrant-officer specification chapters linked from the official site in December 2025. Each entry retains duties across its listed skill levels, qualifications and administrative context. The native classifier selects candidate tasks. Five joint aviation specifications remain grouped, rather than being represented as independently attributed individual MOS profiles. Revisions and future-effective entries remain separate. Army commissioned-officer specifications are outside this collection.
- Navy NEOCS Volume I, Change 107, July 2026 compilation. Each job retains its Navy six-digit job code, rating-wide scope, job description and CORE/NON-CORE task rows with paygrades. Compilation date is not an individual job's effective date. These job codes are not SOC codes. General Naval Standards (January 2023) comprise 517 statements in nine separately coded paygrade records. They are not indiscriminately attached to every job; downstream paygrade-specific combinations require explicit applicability. The general safety statement remains in the full manual; it is not a separately coded job-duty row.
- Marine Corps NAVMC 1200.1L, effective October 1, 2025. Each MOS receives its occupational-field introduction and its own overview. Officer-section metadata includes warrant and mixed officer categories; it does not distinguish commissioned officers perfectly. Many detailed duties refer to separate Training and Readiness manuals that are not part of this collection. FY27 manual 1M was not substituted before its effective date.

The extraction contains 269 Army entries, 252 Navy jobs, 857 Marine entries, and nine Navy general-standard records. Entries are not a count of unique active occupations. Navy table rows become sentences without paraphrase. Source character offsets address the saved layout text; classifier quotation offsets address each record's `body`. Common field/rating text is retained separately as well as included in the coded body. Civilian crosswalk reference sections are retained in raw text but excluded from model input.

## Native coding

JAAT 1.1.3 runs locally with gte-small and task-classifier-mini-v3, using native candidate selection and the native 0.87 task-match threshold. The provenance adapter derives from the supplied CalHR notebook: it observes model decisions without changing the matching algorithm; exact current code hashes are recorded in the run manifest. A task classifier score is not a probability that the O*NET match is correct. JAAT accepts sentences of 5–48 words and truncates classifier inputs at 64 tokens; both limits are auditable. Sentence exclusions, negative classifier decisions, positive-but-unmatched candidates, and accepted assignments are retained.

TitleMatch is run separately on the official entry heading. `refine_titles.py` corrects three Army titles that ran into following prose and restores wrapped Marine headings, then reruns the 501 affected title predictions. The title stage leaves task bodies unchanged; the separately documented footer repair later regenerates affected task bodies and codes. `title_corrections.jsonl` records before/after text and new title predictions. The dashboard applies these explicit corrections. Its output is a title-based comparator, not a military transition recommendation. Titles of grouped specifications can include multiple MOS codes. No title prediction is made for generic Naval Standards. Model revisions, software versions, exact input hash and inference-code hashes are frozen in `outputs/run_manifest.json`. `military_task_profiles.csv` records binary task presence per description, with quotation counts as audit metadata rather than posting frequencies. General-standard records remain identifiable separately. No manual removal of questionable output assignments occurs. Reporting codes, sparse matches, future versions and other limitations are flagged.

## Reproduce

Python 3.13 was used. Install `requirements-lock.txt` in an isolated virtual environment. Poppler's `pdftotext` is required only to regenerate layout text:

```sh
pdftotext -layout sources/army_enlisted.pdf sources/army_enlisted.txt
pdftotext -layout sources/army_warrant.pdf sources/army_warrant.txt
pdftotext -layout sources/navy_jul26.pdf sources/navy_jul26.txt
pdftotext -layout sources/marines_fy26.pdf sources/marines_fy26.txt
python extract_descriptions.py
python -m unittest discover -s tests -v
python reproduce_jaat.py
```

For exact frozen-input reproduction, keep the supplied `inputs/descriptions.jsonl` unchanged and run `reproduce_jaat.py`. Re-extraction is a separate verification step: different Poppler versions can change layout text. The wrapper rejects inputs or software versions that differ from the supplied run rather than silently treating them as the same experiment.

The reproduction wrapper fetches the recorded model revisions, builds a separate local model cache, and writes `outputs/reproduced/`. It preserves the supplied outputs. Initial model downloads require internet access; inference is local. Different numerical libraries/hardware can affect threshold-edge classifications, so compare outputs rather than assume bitwise identity.

To regenerate the audit dashboard from supplied results:

```sh
python build_report.py
python -m http.server 8767 --directory web
```

The dashboard uses only local files and public official military sources. `military_sources_and_coding.zip` and `military_pipeline_code.zip` extract into the same project folder. The source archive includes the independent DMDC July 2024 crosswalk for future comparisons; it was not used as JAAT input. Crosswalk agreement is not observed veteran mobility. No paid API or NLx data is needed for this coding audit.

## Checks

Regression checks cover the actual malformed Army headings (including the source's `1110-15G` typo), adjacent MOS separation, grouped aviation entries, four Navy long-title entries, rating case variants, raw-text boundaries, all nine Naval Standards paygrades, source offsets, body hashes, and formatted SOC-code leakage. The report builder checks every classified quotation against the exact input substring and refuses incomplete task coding. Full manual PDFs remain available for inspection.

## NLx comparison (separate inputs required)

Run `python nlx_crosswalk.py` after `build_report.py`, then `python package_nlx.py`. This optional stage uses the existing repository NLx release aggregates, shared NLx reference RCA weights and reviewed-pair exclusion mask. Those NLx inputs are not included in the public military source archive. The derived comparison package contains all scores, top20 lists, entry-level and branch reference-comparison results, source hashes, and reviewed coding issues.

Six-digit SOC profiles pool weighted specialty task incidences after the existing five-job occupation-task support rule and review mask; each destination requires 200 postings and a nonzero task profile. Eight-digit comparisons are also retained. Military vectors use binary accepted task presence, the same NLx reference RCA weights as the civilian destinations: reciprocal positive task shares (zero weight for reference-absent tasks) of pooled retained support-five NLx weighted incidences across 1,016 reference specialties (912 eligible comparison candidates), followed by sqrt(q * rca_weight), L2 normalization, and cosine. No civilian reference codes enter the ranking. Paygrade-specific Naval Standards remain separate; they are not silently assigned to every Navy job.

DMDC July2024 active-reference codes and civilian SOC references printed in the source manuals are compared separately. Military-specific55-xxxx reference codes cannot be recovered among civilian NLx destinations. The summary keeps these in its all-reference denominator and reports a second hit rate conditional on at least one reference code being available. Summary units are non-future individual source entries, not unique currently active occupations: source versions may repeat. All grouped/future/general-standard entries remain in the full outputs. Known coding errors are flagged and retained in raw benchmarks. Profile similarity is not a transition probability.


## Reviewed pathway pilot

Open `web/pathways.html` for three reviewed profiles (Army 15R, Marine 4422, Navy 002779). After rebuilding the RCA civilian benchmark web files, run `nlx_crosswalk.py`, `select_anchor_models.py`, `review_pathways.py` then `present_pathways.py`. See `outputs/pathway_review/REPRODUCE.txt` for inputs and interpretation. Pre-repair coding and rankings remain archived; the RCA refresh updates military scores and civilian benchmark provider comparisons without new military coding. Every pre-repair candidate remains inspectable.

## 29 September source-extraction repair

Standalone Navy rating/page footers are excluded before continuation assembly. Every Navy task includes source_spans that exactly address the retained layout text; coding-body quotations are normalized assembled text, not necessarily contiguous PDF quotations. Pre-repair files and SHA-256 checksums are preserved in repair_20260929/before.zip and before_manifest.json. repair_coding.py reruns changed bodies with the recorded JAAT 1.1.3 model revisions; unchanged bodies and title predictions are reused. See outputs/run_manifest.json and repair_20260929/comparison.json for counts and result changes. Use the package virtual environment or the locked dependency versions; global Python can have a different JAAT version.

Four specifically unsupported Navy assignments were removed from the provisional review allowlist. All three former supported extension labels are withdrawn: remaining mappings and overlapping duty areas have no independent adjudication. Statement-group ablations are diagnostic, and do not establish independent duty-family robustness. Candidate JSON preserves every prior candidate and adds refreshed candidates, with explicit reasons and quoted evidence. Selected civilian providers use observed in-sample point estimates; their displayed lists use full dashboard SOC6 populations rather than benchmark-specific candidate populations, with no held-out adaptive-policy validation.

The 30 September cache hardening makes `repair_coding.py` reject reused records unless both the current body SHA-256 and a frozen inference-configuration fingerprint match. Legacy cache records without fingerprints are intentionally rejected; preserve them separately before starting a fresh cache. No legacy record is automatically given new provenance. The original executed repair script/hash and unchanged coded-output hash are retained in the repair evidence; `outputs/repair_cache_hardening_manifest.json` separately records the current safer script. This maintenance did not rerun inference.
