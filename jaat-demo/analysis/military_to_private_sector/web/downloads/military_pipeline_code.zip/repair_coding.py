"""Rerun only changed task inputs with frozen native models; preserve before.zip."""
from pathlib import Path
import json,hashlib,zipfile,os,time
P=Path(__file__).resolve().parent
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cache_fingerprint(manifest,adapter_sha256,inventory_sha256):
 """Identify inference semantics independently of a document or cache location."""
 config={k:manifest[k] for k in ['versions','embedding_revision','classifier_revision','task_threshold']}
 config.update(adapter_sha256=adapter_sha256,native_inventory_manifest_sha256=inventory_sha256,
               classifier_batch=32,torch_threads=4,cache_schema=1)
 return hashlib.sha256(json.dumps(config,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def load_cache(path,docs,fingerprint):
 """Fail closed on legacy/stale cache entries before any output can be written."""
 expected={d['doc_id']:d for d in docs};done={}
 for d in docs:
  if hashlib.sha256(d['body'].encode()).hexdigest()!=d['body_sha256']:
   raise ValueError(f"Current body hash is invalid for {d['doc_id']}")
 if not path.exists():return done
 for line in path.read_text().splitlines():
  r=json.loads(line);doc=r['doc_id']
  if doc not in expected or doc in done:
   raise ValueError(f"Unexpected or duplicate cached document: {doc}; preserve the cache and use a new run")
  if r.get('body_sha256')!=expected[doc]['body_sha256']:
   raise ValueError(f"Cached body hash differs for {doc}; preserve the cache and use a new run")
  if r.get('inference_fingerprint')!=fingerprint:
   raise ValueError(f"Cached inference fingerprint missing or different for {doc}; preserve the cache and use a new run")
  done[doc]=r
 return done
def main():
 import torch,JAAT,importlib.metadata
 from JAAT.match import TaskMatch
 from jaat_provenance import tasks_with_confidence
 with zipfile.ZipFile(P/'repair_20260929/before.zip') as z:
  old=json.loads(z.read('outputs/run_manifest.json'));previous={r['doc_id']:r for r in map(json.loads,z.read('outputs/coded_documents.jsonl').decode().splitlines())}
 for package,version in old['versions'].items():assert importlib.metadata.version(package)==version
 docs=list(map(json.loads,(P/'inputs/descriptions.jsonl').read_text().splitlines()))
 changed=[d for d in docs if previous[d['doc_id']]['body_sha256']!=d['body_sha256']]
 out=P/'repair_20260929/recoded.jsonl'
 fingerprint=cache_fingerprint(old,sha(P/'jaat_provenance.py'),sha(P/'outputs/native_inventory_manifest.json'))
 done=load_cache(out,changed,fingerprint)
 pending=[d for d in changed if d['doc_id'] not in done]
 torch.set_num_threads(4);JAAT.toggle_progress(False)
 if pending:
  tm=TaskMatch(embedding_model=old['embedding'],classification_model=old['classifier'],threshold=old['task_threshold'])
  with out.open('a') as f:
   for start in range(0,len(pending),8):
    batch=pending[start:start+8];coded=tasks_with_confidence(tm,batch,classifier_batch=32)
    for d,r in zip(batch,coded):
     result={k:d[k] for k in ['doc_id','body_sha256','branch','military_code','title']};result['task']=r;result['inference_fingerprint']=fingerprint;done[d['doc_id']]=result;f.write(json.dumps(result,ensure_ascii=False)+'\n')
    f.flush();os.fsync(f.fileno());print('RECoded',start+len(batch),'/',len(pending),flush=True)
 previous.update(done)
 (P/'outputs/coded_documents.jsonl').write_text(''.join(json.dumps(previous[d['doc_id']],ensure_ascii=False)+'\n' for d in docs))
 old.update(input_sha256=sha(P/'inputs/descriptions.jsonl'),code_sha256={n:sha(P/n) for n in old['code_sha256']},completed=time.strftime('%Y-%m-%d %H:%M:%S'),repair={'inference_fingerprint':fingerprint,'changed_bodies':len(changed),'unchanged_bodies_reused':len(docs)-len(changed),'script_sha256':sha(Path(__file__)),'before_manifest_sha256':sha(P/'repair_20260929/before_manifest.json'),'policy':'Changed bodies rerun through same frozen native models; original title coding and byte-identical task bodies reused.'})
 (P/'outputs/run_manifest.json').write_text(json.dumps(old,indent=2))
 (P/'repair_20260929/changed_documents.json').write_text(json.dumps([{'doc_id':d['doc_id'],'new_body_sha256':d['body_sha256'],'new_tasks':len({m[0] for m in done[d['doc_id']]['task']['matches']})} for d in changed],indent=2))
 print('Completed',len(changed),flush=True)
if __name__=='__main__':main()
