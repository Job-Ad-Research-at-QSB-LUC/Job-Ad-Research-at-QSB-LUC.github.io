"""Publish a local, inspectable source/coding audit. No NLx data are used."""
from pathlib import Path
import json,csv,hashlib,zipfile,collections,re,shutil,io
ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web';DATA=WEB/'data';DOWNLOAD=WEB/'downloads'
def read(p):return [json.loads(l) for l in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 docs=read(ROOT/'inputs/descriptions.jsonl');coded={d['doc_id']:d for d in read(ROOT/'outputs/coded_documents.jsonl')};titles={d['doc_id']:d for d in read(ROOT/'outputs/title_coding.jsonl')}
 corrections={c['doc_id']:c for c in read(ROOT/'outputs/title_corrections.jsonl')}
 from refine_titles import corrected_title
 expected={d['doc_id'] for d in docs if corrected_title(d)!=d['title']}
 assert set(corrections)==expected,'Title corrections incomplete'
 assert len(coded)==len(docs) and all(d['doc_id'] in coded for d in docs),'Coding is incomplete'
 assert len(titles)==sum(d.get('record_type')!='common_standard' for d in docs),'Title coding is incomplete'
 assert all(d['doc_id'] in titles for d in docs if d.get('record_type')!='common_standard')
 assert len(coded)==len(read(ROOT/'outputs/coded_documents.jsonl')),'Duplicate task records'
 assert len(titles)==len(read(ROOT/'outputs/title_coding.jsonl')),'Duplicate title records'
 source_hashes={name:sha(ROOT/'sources'/name) for name in {d['source_file'] for d in docs}}
 assert all(source_hashes[d['source_file']]==d['source_sha256'] for d in docs),'Source PDF differs from manifest'
 for p in [WEB,DATA,DOWNLOAD]:p.mkdir(exist_ok=True)
 with zipfile.ZipFile(ROOT/'reference/military_crosswalk.zip') as z:
  crosswalk=list(csv.DictReader(io.TextIOWrapper(z.open('military_crosswalk/milx0724.csv'),encoding='utf-8-sig')))
 lookup=collections.defaultdict(list)
 for r in crosswalk:lookup[(r['SVC'],r['MPC'],r['MOC'])].append(r)
 catalog=[];bybranch=collections.defaultdict(collections.Counter);decisions=accepted=0
 counts=collections.Counter((d['branch'],d['military_code']) for d in docs)
 body_counts=collections.Counter((d['branch'],d['body_sha256']) for d in docs)
 for d in docs:
  if d['doc_id'] in corrections:
   correction=corrections[d['doc_id']];assert correction['original_title']==d['title'];assert correction['corrected_title']==corrected_title(d)
   d['title_correction']=correction;d['original_extracted_title']=d['title'];d['title']=correction['corrected_title']
  c=coded[d['doc_id']];assert c['body_sha256']==d['body_sha256'];task=c['task'];flags=[]
  mpc={'enlisted':['E'],'warrant':['W'],'officer':['O','W']}[d['personnel_category']]
  branch={'army':'A','navy':'N','marines':'M'}[d['branch']]
  refs=[r for code in d.get('member_codes',[d['military_code']]) for cat in mpc for r in lookup[(branch,cat,code)]]
  d['reference_crosswalk']={'release':'DMDC July 2024, distributed by O*NET August 2024','match':'Exact branch and code; officer-section entries retain O and W reference candidates separately. Grouped entries retain references to each member code. No rating fallback.','rows':refs}
  if not refs and d.get('record_type')!='common_standard':flags.append('No exact branch/code/personnel-section reference in the 2024 crosswalk')
  for r in task['stage1_decisions']:assert d['body'][r['start_char']:r['end_char']]==r['source_quote']
  if body_counts[(d['branch'],d['body_sha256'])]>1:flags.append('Identical coded text appears in another source entry')
  if d.get('future_effective'):flags.append('Future-effective version')
  if d.get('grouped_specification'):flags.append('Joint specification for multiple MOS codes')
  if counts[(d['branch'],d['military_code'])]>1:flags.append('Code has multiple versions or personnel categories')
  if re.search(r'reporting code|branch/mos immaterial|special duty assignment',d['title']+' '+d['occupation_text'][:150],re.I):flags.append('Administrative/reporting or branch-immaterial code: inspect applicability')
  if not task['matches']:flags.append('No accepted O*NET task matches')
  if len(set(m[0] for m in task['matches']))<5:flags.append('Fewer than five distinct accepted tasks')
  if d['branch']=='marines':flags.append('MOS overview; detailed duties may be in separate Training and Readiness manuals')
  if d['branch']=='marines' and d['personnel_category']=='officer':flags.append('Officer section can include warrant or mixed officer categories')
  if d.get('record_type')=='common_standard':flags.append('General standard; applicability is paygrade-specific')
  if any(s.get('classifier_truncated') for s in task['stage1_decisions']):flags.append('Some classifier inputs truncated at 64 model tokens')
  if task['coverage']['excluded_sentence_indices']:flags.append('Some sentences outside native JAAT 5–48 word range')
  d.update(coding=task,title_coding=corrections.get(d['doc_id'],titles.get(d['doc_id'],{})).get('native_result'),title_coding_input=d['title'],flags=flags)
  unique=len(set(m[0] for m in task['matches']));row={k:d.get(k,'') for k in ['doc_id','branch','military_code','title','personnel_category','rating','effective_month','future_effective','record_type','source_url']}
  row.update(tasks=unique,accepted_statements=len(task['matches']),flags=flags);catalog.append(row)
  (DATA/(d['doc_id']+'.json')).write_text(json.dumps(d,ensure_ascii=False))
  stats=bybranch[d['branch']];stats['records']+=1;stats['general_standard_records']+=d.get('record_type')=='common_standard';stats['with_tasks']+=unique>0;stats['accepted_statements']+=len(task['matches']);stats['distinct_tasks_sum']+=unique
  decisions+=len(task['stage1_decisions']);accepted+=len(task['matches'])
 (DATA/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False))
 summary={'branches':bybranch,'documents':len(docs),'classifier_decisions':decisions,'accepted_statement_matches':accepted,'status':'Complete native task coding; military-to-NLx destination matching pending confirmation of private-employer profiles.','scope':'Army enlisted/warrant, Navy enlisted, Marine officer/enlisted manual entries; not a census of all military jobs.'}
 (DATA/'summary.json').write_text(json.dumps(summary,indent=2))
 with (DOWNLOAD/'military_coverage.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=catalog[0].keys());w.writeheader();w.writerows({**r,'flags':'; '.join(r['flags'])} for r in catalog)
 with (DOWNLOAD/'accepted_task_statements.csv').open('w',newline='') as f:
  fields=['doc_id','branch','military_code','task_id','canonical_task','source_quote','start_char','end_char','classifier_score','classifier_truncated'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for d in docs:
   for s in d['coding']['statements']:
    if not s['matched']:continue
    m=s['accepted_onet_match'];w.writerow(dict(doc_id=d['doc_id'],branch=d['branch'],military_code=d['military_code'],task_id=m[0],canonical_task=m[1],**{k:s[k] for k in fields[5:]}))
 with (DOWNLOAD/'military_task_profiles.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['doc_id','branch','military_code','record_type','task_id','canonical_task','presence','source_statement_count']);w.writeheader()
  for d in docs:
   counts=collections.Counter((m[0],m[1]) for m in d['coding']['matches'])
   for (task_id,task_text),count in sorted(counts.items()):w.writerow(dict(doc_id=d['doc_id'],branch=d['branch'],military_code=d['military_code'],record_type=d.get('record_type','occupation_entry'),task_id=task_id,canonical_task=task_text,presence=1,source_statement_count=count))
 shutil.copyfile(ROOT/'outputs/run_manifest.json',DOWNLOAD/'run_manifest.json')
 (ROOT/'outputs/verification.json').write_text(json.dumps({'input_records':len(docs),'coded_records':len(coded),'title_records':len(titles),'source_quote_spans_verified':decisions,'all_input_body_hashes_match':True,'summary':summary},indent=2))
 with zipfile.ZipFile(DOWNLOAD/'military_pipeline_code.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(ROOT.iterdir()):
   if p.suffix in ['.py','.ipynb'] or p.name in ['README.md','requirements-lock.txt']:z.write(p,p.name)
  for p in (ROOT/'tests').glob('*.py'):z.write(p,p.relative_to(ROOT))
  for p in WEB.iterdir():
   if p.is_file():z.write(p,p.relative_to(ROOT))
 with zipfile.ZipFile(DOWNLOAD/'military_sources_and_coding.zip','w',zipfile.ZIP_DEFLATED) as z:
  for directory in ['sources','inputs','outputs','reference']:
   for p in sorted((ROOT/directory).iterdir()):
    if p.is_file() and not p.name.startswith('initialization_attempt'):z.write(p,p.relative_to(ROOT))
 (DOWNLOAD/'manifest.json').write_text(json.dumps({p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in DOWNLOAD.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2))

 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
