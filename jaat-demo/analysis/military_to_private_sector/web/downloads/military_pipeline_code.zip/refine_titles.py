"""Correct source heading metadata and re-run only affected native title coding.
Task bodies and original run artifacts are immutable. Corrections are explicit.
"""
from pathlib import Path
import json,re,hashlib,time,os
os.environ['HF_HUB_OFFLINE']='1';os.environ['TOKENIZERS_PARALLELISM']='false'
ROOT=Path(__file__).resolve().parent

def corrected_title(d):
 if d['branch']=='army' and d['military_code'] in ['00Z','011A','011M']:
  line=d['raw_text'].strip().splitlines()[0]
  title=re.sub(r'^(?:10|8)-[0-9A-Z]+\.\s*','',line)
  return re.sub(r'^MOS\s+[0-9A-Z]+\s*[—–-]+\s*','',title)
 if d['branch']=='marines':
  head=re.split(r'\n\s*a\.',d['raw_text'],maxsplit=1)[0]
  head=re.sub(r'^\s*\d+\.\s+MOS\s+\d{4},\s*','',head)
  return re.sub(r'\s+',' ',head).strip()
 return d['title']

def main():
 import torch,JAAT
 from JAAT.match import TitleMatch
 from run_jaat import model_path
 from jaat_provenance import jsonable
 torch.set_num_threads(4);JAAT.toggle_progress(False)
 docs=[json.loads(l) for l in (ROOT/'inputs/descriptions.jsonl').read_text().splitlines()]
 changes=[dict(doc_id=d['doc_id'],original_title=d['title'],corrected_title=corrected_title(d),reason='Recover complete source heading; exclude following explanatory prose') for d in docs if corrected_title(d)!=d['title']]
 assert all(len(c['corrected_title'])<600 for c in changes),'Unexpectedly long source heading requires review'
 outdir=Path(os.environ.get('MILITARY_OUTPUT_DIR',str(ROOT/'outputs')));outdir.mkdir(exist_ok=True,parents=True)
 out=outdir/'title_corrections.jsonl'
 run=json.loads((ROOT/'outputs/run_manifest.json').read_text())
 assert model_path('thenlper/gte-small')[1]==run['embedding_revision']
 for repo,revision in run['title_models'].items():assert model_path(repo)[1]==revision, 'Title model revision changed'
 title=TitleMatch(batch_size=16,embedding_model=model_path('thenlper/gte-small')[0])
 with out.open('w') as f:
  for start in range(0,len(changes),16):
   batch=changes[start:start+16];result=title.get_title([c['corrected_title'] for c in batch])
   for c,r in zip(batch,result):f.write(json.dumps(dict(c,native_result=jsonable(r)))+'\n')
   f.flush();print('Corrected titles',start+len(batch),'/',len(changes),flush=True)
 run=json.loads((ROOT/'outputs/run_manifest.json').read_text())
 (outdir/'title_correction_manifest.json').write_text(json.dumps({'completed':time.strftime('%Y-%m-%d %H:%M:%S'),'records':len(changes),'input_sha256':hashlib.sha256((ROOT/'inputs/descriptions.jsonl').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'models':run['title_models'],'embedding_revision':model_path('thenlper/gte-small')[1],'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'note':'Task bodies and original task/title outputs remain unchanged. Dashboard uses explicitly corrected title predictions where present.'},indent=2))
if __name__=='__main__':main()
