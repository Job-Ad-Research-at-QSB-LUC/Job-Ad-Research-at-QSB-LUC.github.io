"""Publish compact pre/post evidence without environment files or NLx inputs."""
from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent;R=P/'repair_20260929';D=P/'web/downloads'
with zipfile.ZipFile(R/'before.zip') as old,zipfile.ZipFile(D/'military_repair_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['extract_descriptions.py','inputs/descriptions.jsonl','outputs/coded_documents.jsonl','outputs/run_manifest.json','outputs/nlx_crosswalk/all_scores_soc6.npz','outputs/nlx_crosswalk/all_scores_soc8.npz','outputs/pathway_review/task_review.json','outputs/pathway_review/manifest.json']:
  z.writestr('before/'+n,old.read(n))
 for n in ['before_manifest.json','comparison.json','changed_documents.json','native_inventory_verified.txt','inference.log','repair_coding_executed_20260929.py']:
  z.write(R/n,'repair/'+n)
 for n in ['repair_coding.py','repair_report.py','package_repair.py','extract_descriptions.py','review_pathways.py','select_anchor_models.py','present_pathways.py','public_nlx_evidence.py']:
  z.write(P/n,'after/'+n)
 for n in ['run_manifest.json','repair_cache_hardening_manifest.json','pathway_review/manifest.json','pathway_review/task_review.json']:
  z.write(P/'outputs'/n,'after/outputs/'+n)
 z.writestr('README.txt','Original military inputs and task codes precede footer repair. Current military_sources_and_coding.zip contains cleaned inputs and full regenerated outputs. Original official PDFs and layout text are unchanged. No NLx inputs are redistributed. before_manifest.json also inventories private local environment files which are not redistributed here. Read comparison.json for observed changes.\n')
files={str(p.relative_to(P)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in P.rglob('*') if p.is_file() and any(x in p.parts for x in ['inputs','outputs','sources']) and '__pycache__' not in p.parts}
(R/'after_manifest.json').write_text(json.dumps(files,indent=2))
(D/'manifest.json').write_text(json.dumps({p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in D.iterdir() if p.is_file() and p.name!='manifest.json'},indent=2))
print('Published military_repair_evidence.zip; after_manifest.json and downloads manifest refreshed')
