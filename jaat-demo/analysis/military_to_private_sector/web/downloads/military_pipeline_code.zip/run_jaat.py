"""Resumable native JAAT 1.1.3 task/title coding with CalHR provenance adapters."""
from pathlib import Path
import json,hashlib,os,time,importlib.metadata
ROOT=Path(__file__).resolve().parent
os.environ['TOKENIZERS_PARALLELISM']='false'
os.environ['HF_HUB_OFFLINE']='1'
import torch,nltk,JAAT
from JAAT.match import TaskMatch,TitleMatch
from jaat_provenance import tasks_with_confidence,jsonable
OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
def model_path(repo):
    base=Path.home()/'.cache/huggingface/hub'/('models--'+repo.replace('/','--'))
    ref=base/'refs/main'
    if ref.exists():
        revision=ref.read_text().strip();p=base/'snapshots'/revision
        if p.exists():return str(p),revision
    return repo,'resolved_by_huggingface'
def main():
    assert importlib.metadata.version('JAAT')=='1.1.3'
    torch.set_num_threads(4);JAAT.toggle_progress(False)
    try:nltk.sent_tokenize('One sentence. Another sentence.')
    except LookupError:nltk.download('punkt_tab',quiet=True)
    docs=[json.loads(l) for l in (ROOT/'inputs/descriptions.jsonl').read_text().splitlines()]
    embedding,er=model_path('thenlper/gte-small');classifier,cr=model_path('loyoladatamining/task-classifier-mini-v3')
    manifest={'versions':{p:importlib.metadata.version(p) for p in ['JAAT','torch','transformers','sentence-transformers','nltk']},'embedding':embedding,'embedding_revision':er,'classifier':classifier,'classifier_revision':cr,'input_sha256':hashlib.sha256((ROOT/'inputs/descriptions.jsonl').read_bytes()).hexdigest(),'task_threshold':.87,'inference':'Native JAAT task and title tools; no SOC crosswalk text provided to models.','started':time.strftime('%Y-%m-%d %H:%M:%S')}
    manifest['title_models']={repo:model_path(repo)[1] for repo in ['loyoladatamining/title_value','loyoladatamining/title_feature']}
    manifest['title_feature_threshold']=.95
    manifest['code_sha256']={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_jaat.py','jaat_provenance.py','extract_descriptions.py']}
    mf=OUT/'run_manifest.json'
    if mf.exists():
        previous=json.loads(mf.read_text())
        for k in ['input_sha256','versions','embedding_revision','classifier_revision','title_models','code_sha256','task_threshold']:
            assert previous[k]==manifest[k],f'Run identity changed: {k}; use new output run'
        manifest['started']=previous['started']
    mf.write_text(json.dumps(manifest,indent=2))
    results=OUT/'coded_documents.jsonl';done={}
    if results.exists():
        for line in results.read_text().splitlines():
            r=json.loads(line);done[r['doc_id']]=r
    pending=[d for d in docs if d['doc_id'] not in done]
    if pending:
        print('Loading native JAAT task tool',len(pending),'documents',flush=True);tm=TaskMatch(embedding_model=embedding,classification_model=classifier)
        with results.open('a') as f:
            for start in range(0,len(pending),8):
                batch=pending[start:start+8];coded=tasks_with_confidence(tm,batch,classifier_batch=32)
                for d,r in zip(batch,coded):
                    record={'doc_id':d['doc_id'],'body_sha256':d['body_sha256'],'branch':d['branch'],'military_code':d['military_code'],'title':d['title'],'task':r};f.write(json.dumps(record,ensure_ascii=False)+'\n')
                f.flush();os.fsync(f.fileno());print('TASK',start+len(batch),'/',len(pending),flush=True)
        del tm
    titles=OUT/'title_coding.jsonl';tdone=set()
    if titles.exists():tdone={json.loads(l)['doc_id'] for l in titles.read_text().splitlines()}
    pending=[d for d in docs if d['doc_id'] not in tdone and d.get('record_type')!='common_standard']
    if pending:
        print('Loading native JAAT title tool',flush=True);title=TitleMatch(batch_size=16,embedding_model=embedding)
        with titles.open('a') as f:
            for start in range(0,len(pending),16):
                batch=pending[start:start+16];coded=title.get_title([d['title'] for d in batch])
                assert len(coded)==len(batch)
                for d,r in zip(batch,coded):f.write(json.dumps({'doc_id':d['doc_id'],'input_title':d['title'],'native_result':jsonable(r)})+'\n')
                f.flush();print('TITLE',start+len(batch),'/',len(pending),flush=True)
    manifest['completed']=time.strftime('%Y-%m-%d %H:%M:%S');manifest['documents']=len(docs);mf.write_text(json.dumps(manifest,indent=2));print('JAAT coding complete',flush=True)
if __name__=='__main__':main()
